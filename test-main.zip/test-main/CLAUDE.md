# Claude / Fable 5 — project brief

Read **`AGENTS.md` first.** Especially the **creative freedom** rules.

## What this is

Self-hosted **Imagine Engine**: text-to-image studio, stdlib Python server +
vanilla web UI. Multi-provider: local **`dream`**, optional **Replicate**
(Flux), optional **xAI** / OpenAI. Share to X optional; download always.

## Your mandate when improving

1. **Keep creative freedom of the local setup** — offline `dream` always works;
   never lock the product to one hosted model; no global prompt censorship on
   local generation.
2. Hosted quality (Flux Max, Grok Imagine, etc.) is **additive** via providers.
3. Do not commit `.env` or tokens. Prefer zero-pip stdlib.
4. Verify with: no keys → generate still works; with keys → can still pick dream.

## Useful entry points

- `server.py` — HTTP API + static UI  
- `engine/core.py` — router + gallery  
- `engine/dream.py` — local freedom path  
- `engine/providers.py` — remote adapters  
- `engine/share_x.py` — optional X post  
- `web/` — UI  

## Verify skill

See `.claude/skills/verify/SKILL.md` for launch / smoke patterns.
