"""Turn a text prompt into a deterministic scene specification.

The local "dream" renderer is not a diffusion model — it reads the prompt for
palette and scene-element keywords, derives a seed from the text, and renders
a procedural artwork. Same prompt + same seed => identical image.
"""

import hashlib
import random
from dataclasses import dataclass, field

# Sky gradients run top -> horizon. `sun` is the celestial body / glow color.
PALETTES = {
    "sunset": dict(sky=[(24, 18, 52), (122, 42, 84), (224, 98, 58), (255, 178, 86)],
                   sun=(255, 214, 140), night=False),
    "ocean":  dict(sky=[(10, 42, 84), (28, 90, 140), (90, 168, 200), (214, 236, 240)],
                   sun=(255, 240, 200), night=False),
    "forest": dict(sky=[(26, 52, 58), (52, 96, 88), (120, 160, 120), (216, 228, 180)],
                   sun=(250, 244, 190), night=False),
    "night":  dict(sky=[(4, 6, 20), (10, 16, 40), (24, 34, 66), (60, 74, 108)],
                   sun=(232, 236, 246), night=True),
    "space":  dict(sky=[(6, 4, 18), (16, 10, 38), (36, 18, 64), (74, 36, 100)],
                   sun=(240, 235, 255), night=True),
    "neon":   dict(sky=[(10, 6, 30), (44, 10, 64), (122, 20, 110), (255, 64, 124)],
                   sun=(255, 228, 120), night=True),
    "desert": dict(sky=[(60, 34, 60), (160, 80, 70), (230, 140, 80), (250, 205, 130)],
                   sun=(255, 235, 180), night=False),
    "ice":    dict(sky=[(30, 50, 80), (80, 120, 160), (150, 190, 215), (230, 244, 250)],
                   sun=(255, 255, 240), night=False),
    "fire":   dict(sky=[(20, 4, 8), (80, 14, 16), (180, 50, 20), (255, 140, 40)],
                   sun=(255, 220, 150), night=False),
    "pastel": dict(sky=[(120, 110, 170), (190, 140, 180), (240, 180, 190), (255, 225, 210)],
                   sun=(255, 250, 230), night=False),
    "meadow": dict(sky=[(70, 120, 190), (120, 170, 220), (180, 215, 240), (235, 245, 250)],
                   sun=(255, 250, 220), night=False),
}

PALETTE_KEYWORDS = {
    "sunset": ("sunset", "sunrise", "dusk", "dawn", "twilight", "golden hour", "sundown"),
    "ocean":  ("ocean", "sea", "beach", "coast", "wave", "shore", "island", "lagoon", "harbor"),
    "forest": ("forest", "jungle", "woods", "woodland", "rainforest", "grove"),
    "night":  ("night", "midnight", "moonlit", "moonlight", "dark sky"),
    "space":  ("space", "galaxy", "nebula", "cosmos", "cosmic", "aurora", "universe", "planet"),
    "neon":   ("neon", "cyberpunk", "synthwave", "vaporwave", "retrowave", "futuristic city"),
    "desert": ("desert", "dune", "sahara", "canyon", "mesa", "badlands"),
    "ice":    ("ice", "snow", "winter", "arctic", "glacier", "frozen", "frost"),
    "fire":   ("fire", "lava", "volcano", "inferno", "ember", "flame"),
    "pastel": ("pastel", "dream", "dreamy", "soft", "cotton candy", "ethereal"),
    "meadow": ("meadow", "field", "spring", "prairie", "countryside", "hills"),
}

ELEMENT_KEYWORDS = {
    "mountains": ("mountain", "peak", "alps", "ridge", "hill", "cliff", "canyon",
                  "valley", "summit", "volcano", "mesa", "dune"),
    "water":     ("ocean", "sea", "lake", "river", "water", "beach", "wave", "coast",
                  "shore", "lagoon", "reflection", "harbor", "bay"),
    "city":      ("city", "skyline", "cyberpunk", "town", "metropolis", "skyscraper",
                  "urban", "downtown", "rooftop"),
    "trees":     ("forest", "tree", "pine", "woods", "jungle", "grove", "palm"),
    "stars":     ("star", "night", "galaxy", "space", "cosmos", "midnight", "constellation"),
    "moon":      ("moon", "lunar", "moonlit", "moonlight", "midnight"),
    "nebula":    ("nebula", "galaxy", "space", "cosmos", "aurora", "universe"),
    "clouds":    ("cloud", "storm", "mist", "fog", "overcast", "sky"),
}


@dataclass
class SceneSpec:
    mode: str                 # "landscape" | "abstract"
    palette: str
    sky: list
    sun: tuple
    night: bool
    elements: set
    seed: int
    rng: random.Random = field(repr=False, default=None)


# Seeds stay under 2^53 so they survive JSON -> JavaScript number round-trips;
# a displayed seed can be typed back in to reproduce the exact image.
_SEED_MASK = (1 << 53) - 1


def derive_seed(prompt: str, seed=None, variant: int = 0) -> int:
    """Resolve the effective seed for one image.

    A user-supplied seed is used directly (offset per variant), so the seed
    shown on a result reproduces that result. Otherwise the seed is hashed
    from the prompt text.
    """
    if seed is not None:
        return (int(seed) + variant) & _SEED_MASK
    material = f"{prompt.strip().lower()}|{variant}"
    digest = hashlib.sha256(material.encode("utf-8")).digest()
    return int.from_bytes(digest[:8], "big") >> 11


def build_spec(prompt: str, seed=None, variant: int = 0) -> SceneSpec:
    text = prompt.lower()
    resolved_seed = derive_seed(prompt, seed, variant)
    rng = random.Random(resolved_seed)

    palette = None
    for name, words in PALETTE_KEYWORDS.items():
        if any(w in text for w in words):
            palette = name
            break

    elements = {name for name, words in ELEMENT_KEYWORDS.items()
                if any(w in text for w in words)}

    # A prompt with no scenery cues gets an abstract composition instead of
    # pretending to be a landscape.
    mode = "landscape" if palette or elements else "abstract"
    if palette is None:
        palette = rng.choice(list(PALETTES))

    if mode == "landscape":
        # Sensible defaults so a bare "sunset" still composes a full scene.
        if not elements & {"mountains", "city", "trees"}:
            elements.add("mountains")
        if "water" not in elements and rng.random() < 0.45:
            elements.add("water")
        if "clouds" not in elements and rng.random() < 0.6:
            elements.add("clouds")
        if PALETTES[palette]["night"]:
            elements.add("stars")
            if palette != "space":
                elements.add("moon")
        if palette == "space":
            elements.update({"stars", "nebula"})
        if palette == "neon":
            elements.add("city")

    pal = PALETTES[palette]
    return SceneSpec(
        mode=mode,
        palette=palette,
        sky=pal["sky"],
        sun=pal["sun"],
        night=pal["night"],
        elements=elements,
        seed=resolved_seed,
        rng=rng,
    )


SURPRISE_PROMPTS = [
    "neon cyberpunk skyline reflected in a rain-soaked bay",
    "golden hour over a pine forest lake",
    "aurora over a frozen mountain ridge at midnight",
    "a nebula blooming above alien canyons",
    "pastel dream of floating islands at dawn",
    "lava fields under a smoke-red sky",
    "moonlit desert dunes with distant mesas",
    "storm clouds rolling over a coastal city",
]
