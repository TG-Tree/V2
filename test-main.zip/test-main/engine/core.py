"""Orchestrator: routes generation requests to a provider and manages the
on-disk gallery."""

import base64
import json
import os
import threading
import time
import uuid

from . import dream, png
from .providers import (PROVIDERS, ProviderError, available_remote_providers,
                        provider_info)


def _decode_data_url(image: str):
    """Decode a data:image/png;base64 URL into (width, height, rgb)."""
    try:
        _, b64 = image.split(",", 1)
        return png.decode(base64.b64decode(b64))
    except (ValueError, IndexError) as exc:
        raise ProviderError(f"could not decode input image: {exc}") from exc

GALLERY_LIMIT = 2000


class ImagineEngine:
    def __init__(self, out_dir: str):
        self.out_dir = out_dir
        os.makedirs(out_dir, exist_ok=True)
        self._index_path = os.path.join(out_dir, "gallery.json")
        self._lock = threading.Lock()

    # -- provider selection ---------------------------------------------------

    def default_provider(self) -> str:
        forced = os.environ.get("IMAGINE_PROVIDER")
        if forced:
            return forced
        remotes = available_remote_providers()
        return remotes[0] if remotes else "dream"

    def provider_status(self) -> dict:
        infos = [{
            "name": "dream", "label": "dream (local)", "local": True,
            "img2img": True, "seed": True, "available": True,
            "detail": "built-in procedural renderer — zero config, works offline",
        }] + provider_info()
        return {
            "active": self.default_provider(),
            "available": ["dream"] + available_remote_providers(),
            "providers": infos,
            "aspects": list(dream.ASPECTS),
            "styles": list(dream.STYLES),
        }

    # -- generation -------------------------------------------------------------

    def generate(self, prompt: str, n: int = 1, aspect: str = "1:1",
                 style: str = "vivid", seed=None, provider: str = None,
                 image: str = None, strength: float = 0.75) -> list:
        provider = provider or self.default_provider()
        if provider == "dream":
            images = []
            if image:
                src_w, src_h, rgb = _decode_data_url(image)
                for variant in range(n):
                    try:
                        data, width, height, used_seed = dream.remix(
                            rgb, src_w, src_h, prompt, style=style, seed=seed,
                            variant=variant, strength=strength)
                    except ValueError as exc:
                        raise ProviderError(str(exc)) from exc
                    images.append((data, width, height, used_seed))
            else:
                for variant in range(n):
                    data, width, height, used_seed = dream.generate(
                        prompt, aspect=aspect, style=style, seed=seed, variant=variant)
                    images.append((data, width, height, used_seed))
        elif provider in PROVIDERS:
            remote = PROVIDERS[provider]["fn"](
                prompt, n, aspect, image=image, strength=strength,
                style=style, seed=seed)
            images = []
            for item in remote:
                # Adapters may report the seed the backend actually used.
                data, used = item if isinstance(item, tuple) else (item, seed)
                dims = png.dimensions(data)
                width, height = dims if dims else (None, None)
                images.append((data, width, height, used))
        else:
            raise ProviderError(f"unknown provider: {provider}")

        records = []
        created = time.time()
        for data, width, height, used_seed in images:
            is_png = data[:8] == b"\x89PNG\r\n\x1a\n"
            ext = "png" if is_png else "jpg"
            if is_png:
                # Downloaded files carry their own recipe.
                data = png.add_metadata(data, {
                    "prompt": prompt,
                    "seed": used_seed,
                    "provider": provider,
                    "style": style,
                    "aspect": aspect,
                    "software": "Imagine Engine",
                })
            image_id = f"{int(created)}-{uuid.uuid4().hex[:10]}"
            filename = f"{image_id}.{ext}"
            with open(os.path.join(self.out_dir, filename), "wb") as fh:
                fh.write(data)
            records.append({
                "id": image_id,
                "url": f"/images/{filename}",
                "prompt": prompt,
                "provider": provider,
                "aspect": aspect,
                "style": style,
                "seed": used_seed,
                "width": width,
                "height": height,
                "img2img": bool(image),
                "created": created,
            })
        self._append_records(records)
        return records

    # -- gallery -----------------------------------------------------------------

    def gallery(self, offset: int = 0, limit: int = None):
        """Return (records, total) for one page of the index, newest first."""
        with self._lock:
            index = self._read_index()
        total = len(index)
        if limit is not None:
            index = index[offset:offset + limit]
        elif offset:
            index = index[offset:]
        return index, total

    def delete(self, image_id: str) -> bool:
        """Remove one image from the index and disk. Returns True if anything
        was deleted."""
        if not image_id or image_id != os.path.basename(image_id):
            return False
        with self._lock:
            index = self._read_index()
            kept = [rec for rec in index if rec.get("id") != image_id]
            in_index = len(kept) != len(index)
            if in_index:
                self._write_index(kept)
        on_disk = False
        for ext in ("png", "jpg"):
            path = os.path.join(self.out_dir, f"{image_id}.{ext}")
            if os.path.isfile(path):
                os.remove(path)
                on_disk = True
        return in_index or on_disk

    def _read_index(self) -> list:
        try:
            with open(self._index_path, "r", encoding="utf-8") as fh:
                return json.load(fh)
        except (FileNotFoundError, json.JSONDecodeError):
            return []

    def _write_index(self, index: list):
        tmp = self._index_path + ".tmp"
        with open(tmp, "w", encoding="utf-8") as fh:
            json.dump(index, fh)
        os.replace(tmp, self._index_path)

    def _append_records(self, records: list):
        with self._lock:
            index = self._read_index()
            self._write_index((records + index)[:GALLERY_LIMIT])
