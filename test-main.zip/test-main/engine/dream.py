"""The built-in "dream" renderer.

A deterministic, dependency-free procedural artist: it composes seeded
landscapes (sky, celestial bodies, nebulae, ridgelines, skylines, water) or
abstract flow-fields from a SceneSpec, entirely in pure Python. It is an art
engine, not a diffusion model — hosted providers cover photorealism.
"""

import math

from . import png
from .noise import NoiseField, ridgeline
from .prompt import SceneSpec, build_spec

ASPECTS = {
    "1:1": (512, 512),
    "16:9": (640, 360),
    "9:16": (360, 640),
    "4:3": (560, 420),
    "3:4": (420, 560),
    "21:9": (672, 288),
}

STYLES = ("vivid", "muted", "mono", "noir")

_STYLE_SATURATION = {"vivid": 1.14, "muted": 0.68, "mono": 0.0, "noir": 0.4}


def _clamp(v, lo=0, hi=255):
    return lo if v < lo else hi if v > hi else v


def _mix(c1, c2, t):
    return (
        int(c1[0] + (c2[0] - c1[0]) * t),
        int(c1[1] + (c2[1] - c1[1]) * t),
        int(c1[2] + (c2[2] - c1[2]) * t),
    )


def _grad(stops, t):
    """Sample a multi-stop gradient at t in [0, 1]."""
    if t <= 0:
        return stops[0]
    if t >= 1:
        return stops[-1]
    pos = t * (len(stops) - 1)
    i = int(pos)
    return _mix(stops[i], stops[i + 1], pos - i)


class DreamRenderer:
    def __init__(self, spec: SceneSpec, width: int, height: int):
        self.spec = spec
        self.w = width
        self.h = height
        self.img = bytearray(width * height * 3)

    # -- pixel helpers -----------------------------------------------------

    def _put(self, x, y, color):
        i = (y * self.w + x) * 3
        self.img[i] = color[0]
        self.img[i + 1] = color[1]
        self.img[i + 2] = color[2]

    def _blend(self, x, y, color, a):
        """Alpha-blend color onto the framebuffer at (x, y)."""
        i = (y * self.w + x) * 3
        img = self.img
        img[i] = int(img[i] + (color[0] - img[i]) * a)
        img[i + 1] = int(img[i + 1] + (color[1] - img[i + 1]) * a)
        img[i + 2] = int(img[i + 2] + (color[2] - img[i + 2]) * a)

    def _add(self, x, y, color, a):
        """Additively blend (for glows and stars)."""
        i = (y * self.w + x) * 3
        img = self.img
        img[i] = _clamp(int(img[i] + color[0] * a))
        img[i + 1] = _clamp(int(img[i + 1] + color[1] * a))
        img[i + 2] = _clamp(int(img[i + 2] + color[2] * a))

    def _fill_row(self, y, color):
        r, g, b = color
        row = bytes((r, g, b)) * self.w
        start = y * self.w * 3
        self.img[start:start + self.w * 3] = row

    # -- landscape passes ---------------------------------------------------

    def render(self) -> bytes:
        if self.spec.mode == "landscape":
            self._render_landscape()
        else:
            self._render_abstract()
        self._finish()
        return png.encode(self.w, self.h, self.img)

    def _render_landscape(self):
        spec, rng, w, h = self.spec, self.spec.rng, self.w, self.h
        horizon = int(h * rng.uniform(0.58, 0.72))
        has_water = "water" in spec.elements

        # 1. Sky fills the whole frame; ground/water passes overwrite below.
        for y in range(h):
            t = min(1.0, y / max(1, horizon))
            self._fill_row(y, _grad(spec.sky, t))

        if "nebula" in spec.elements:
            self._pass_nebula(horizon)
        if "stars" in spec.elements:
            self._pass_stars(horizon)

        sun = None
        if not spec.night or "moon" in spec.elements or spec.palette == "space":
            sun = self._pass_celestial(horizon)
        if "clouds" in spec.elements:
            self._pass_clouds(horizon)
        if "mountains" in spec.elements:
            self._pass_mountains(horizon)
        if "city" in spec.elements:
            self._pass_city(horizon)

        if has_water:
            self._pass_water(horizon, sun)
        else:
            self._pass_ground(horizon)
            if "trees" in spec.elements:
                self._pass_trees(horizon)

    def _pass_celestial(self, horizon):
        """Sun or moon disk with a soft radial glow. Returns (cx, cy, color)."""
        spec, rng, w, h = self.spec, self.spec.rng, self.w, self.h
        is_moon = spec.night and spec.palette != "neon"
        cx = int(rng.uniform(0.2, 0.8) * w)
        cy = int(rng.uniform(0.2, 0.65) * horizon)
        radius = h * (rng.uniform(0.035, 0.055) if is_moon else rng.uniform(0.05, 0.09))
        glow = radius * (3.2 if not is_moon else 2.4)
        color = spec.sun

        y0, y1 = max(0, int(cy - glow)), min(horizon, int(cy + glow) + 1)
        x0, x1 = max(0, int(cx - glow)), min(w, int(cx + glow) + 1)
        for y in range(y0, y1):
            dy2 = (y - cy) ** 2
            for x in range(x0, x1):
                d = math.sqrt((x - cx) ** 2 + dy2)
                if d <= radius:
                    self._blend(x, y, color, 0.96)
                elif d < glow:
                    fall = (1.0 - (d - radius) / (glow - radius)) ** 2
                    self._add(x, y, color, fall * 0.32)
        if is_moon:
            # A bite of shadow makes it read as a crescent.
            ox, oy = int(radius * 0.45), int(-radius * 0.2)
            for y in range(max(0, cy - int(radius)), min(horizon, cy + int(radius) + 1)):
                for x in range(max(0, cx - int(radius)), min(w, cx + int(radius) + 1)):
                    d = math.sqrt((x - (cx + ox)) ** 2 + (y - (cy + oy)) ** 2)
                    if d <= radius * 0.92:
                        self._blend(x, y, _grad(spec.sky, 0.15), 0.85)
        return (cx, cy, color)

    def _pass_stars(self, horizon):
        spec, rng, w = self.spec, self.spec.rng, self.w
        count = int(w * horizon / 900)
        for _ in range(count):
            x = rng.randrange(w)
            y = rng.randrange(horizon)
            b = rng.uniform(0.25, 1.0) * (1.0 - y / horizon * 0.4)
            self._add(x, y, (255, 255, 255), b)
            if b > 0.85 and 1 <= x < w - 1 and 1 <= y < horizon - 1:
                for dx, dy in ((1, 0), (-1, 0), (0, 1), (0, -1)):
                    self._add(x + dx, y + dy, (255, 255, 255), b * 0.35)

    def _pass_nebula(self, horizon):
        spec, w = self.spec, self.w
        f1 = NoiseField(w, self.h, scale=w / 1.7, seed=spec.seed ^ 0x4E42, octaves=5)
        f2 = NoiseField(w, self.h, scale=w / 2.6, seed=spec.seed ^ 0x4E43, octaves=4)
        c1 = _mix(spec.sky[-1], (200, 80, 220), 0.6)
        c2 = _mix(spec.sky[-1], (70, 140, 230), 0.6)
        for y in range(horizon):
            for x in range(w):
                v1 = f1.at(x, y) - 0.52
                if v1 > 0:
                    self._add(x, y, c1, min(0.5, v1 * 1.8))
                v2 = f2.at(x, y) - 0.55
                if v2 > 0:
                    self._add(x, y, c2, min(0.4, v2 * 1.6))

    def _pass_clouds(self, horizon):
        spec, w = self.spec, self.w
        # Sampled at y*1.9, so the field needs ~2x the vertical extent.
        field = NoiseField(w, self.h * 2, scale=w / 2.2, seed=spec.seed ^ 0xC10D, octaves=5)
        base = _mix(spec.sky[-1], (255, 255, 255), 0.5)
        shade = _mix(spec.sky[1], (30, 30, 40), 0.3)
        color = base if not spec.night else _mix(spec.sky[-1], (200, 205, 222), 0.3)
        y0, y1 = int(horizon * 0.06), horizon
        span = max(1, y1 - y0)
        for y in range(y0, y1):
            envelope = math.sin((y - y0) / span * math.pi) ** 0.7
            for x in range(w):
                v = field.at(x, y * 1.9) - 0.52
                if v <= 0:
                    continue
                a = min(0.85, v * 3.2) * envelope
                # Darker undersides give the clouds volume.
                under = field.at(x, y * 1.9 - 6) - 0.52
                tone = shade if under > v + 0.02 else color
                self._blend(x, y, tone, a)

    def _pass_mountains(self, horizon):
        spec, rng, w = self.spec, self.spec.rng, self.w
        layers = rng.randint(2, 4)
        near = _mix(spec.sky[0], (8, 8, 14), 0.55)
        fog = _mix(spec.sky[-1], near, 0.3)
        snowy = spec.palette == "ice"
        for k in range(layers):
            depth = (k + 1) / layers                      # 0 -> farthest
            amp = horizon * (0.12 + 0.3 * depth)
            ridge = ridgeline(rng, w, roughness=0.85)
            color = _mix(fog, near, depth ** 1.2)
            snow_line = 0.72
            for x in range(w):
                top = int(horizon - amp * ridge[x])
                if top < 0:
                    top = 0
                for y in range(top, horizon):
                    self._put(x, y, color)
                if snowy and ridge[x] > snow_line:
                    cap = int((ridge[x] - snow_line) * amp)
                    for y in range(top, min(horizon, top + max(1, cap // 2))):
                        self._blend(x, y, (235, 242, 250), 0.8)

    def _pass_city(self, horizon):
        spec, rng, w = self.spec, self.spec.rng, self.w
        body = _mix(spec.sky[0], (6, 6, 12), 0.7)
        window_colors = ((255, 196, 96), (140, 220, 255), (255, 120, 180))
        x = 0
        while x < w - 2:
            bw = rng.randint(max(6, w // 60), max(10, w // 22))
            bh = int(horizon * rng.uniform(0.08, 0.42))
            top = horizon - bh
            for bx in range(x, min(w, x + bw)):
                for y in range(top, horizon):
                    self._put(bx, y, body)
            if spec.night:
                for wy in range(top + 3, horizon - 2, 4):
                    for wx in range(x + 2, min(w, x + bw) - 1, 4):
                        if rng.random() < 0.4:
                            self._put(wx, wy, rng.choice(window_colors))
            if bh > horizon * 0.3 and rng.random() < 0.4:  # antenna spire
                ax = x + bw // 2
                if ax < w:
                    for y in range(max(0, top - bh // 6), top):
                        self._put(ax, y, body)
            x += bw + rng.randint(1, 4)

    def _pass_water(self, horizon, sun):
        spec, w, h = self.spec, self.w, self.h
        img = self.img
        field = NoiseField(w, h, scale=w / 7.0, seed=spec.seed ^ 0xAA7E, octaves=3)
        deep = _mix(spec.sky[0], (4, 10, 24), 0.5)
        depth_span = max(1, h - horizon)
        for y in range(horizon, h):
            depth = (y - horizon) / depth_span
            amp = 2 + depth * 14
            fade = 0.22 + 0.4 * depth
            for x in range(w):
                ripple = (field.at(x, y) - 0.5) * amp
                sy = int(2 * horizon - y + ripple)
                if sy < 0:
                    sy = 0
                elif sy >= horizon:
                    sy = horizon - 1
                src = (sy * w + x) * 3
                dst = (y * w + x) * 3
                img[dst] = int(img[src] + (deep[0] - img[src]) * fade)
                img[dst + 1] = int(img[src + 1] + (deep[1] - img[src + 1]) * fade)
                img[dst + 2] = int(img[src + 2] + (deep[2] - img[src + 2]) * fade)
        if sun:
            cx, _, color = sun
            for y in range(horizon + 1, h):
                depth = (y - horizon) / depth_span
                wiggle = (field.at(cx, y * 3) - 0.5) * 10
                half = max(1.0, w * 0.015 * (1 - depth * 0.5))
                x0 = max(0, int(cx + wiggle - half * 2))
                x1 = min(w, int(cx + wiggle + half * 2) + 1)
                for x in range(x0, x1):
                    d = abs(x - cx - wiggle) / (half * 2)
                    if d < 1.0:
                        self._add(x, y, color, (1 - d) ** 2 * 0.3 * (1 - depth * 0.6))

    def _pass_ground(self, horizon):
        spec, w, h = self.spec, self.w, self.h
        greenish = spec.palette in ("forest", "meadow")
        base = (26, 44, 30) if greenish else _mix(spec.sky[0], (16, 16, 18), 0.65)
        fog = _mix(_grad(spec.sky, 1.0), base, 0.45)
        field = NoiseField(w, h, scale=w / 4.0, seed=spec.seed ^ 0x6D0D, octaves=3)
        span = max(1, h - horizon)
        for y in range(horizon, h):
            depth = (y - horizon) / span
            row = _mix(fog, base, min(1.0, depth * 1.6))
            self._fill_row(y, row)
            for x in range(w):
                v = field.at(x * 1.4, y) - 0.5
                if v > 0:
                    self._blend(x, y, (0, 0, 0), min(0.3, v * 0.9) * depth)

    def _pass_trees(self, horizon):
        spec, rng, w, h = self.spec, self.spec.rng, self.w, self.h
        color = (10, 18, 12)
        count = max(10, w // 16)
        for _ in range(count):
            base_y = rng.randint(horizon + 4, h - 2)
            perspective = (base_y - horizon) / max(1, h - horizon)
            size = int(6 + perspective * h * 0.12)
            x = rng.randrange(w)
            for dy in range(size):
                half = int((dy / size) * size * 0.35) + 1
                y = base_y - size + dy
                if 0 <= y < h:
                    for dx in range(-half, half + 1):
                        if 0 <= x + dx < w:
                            self._blend(x + dx, y, color, 0.9)

    # -- abstract mode -------------------------------------------------------

    def _render_abstract(self):
        spec, rng, w, h = self.spec, self.spec.rng, self.w, self.h
        warp_x = NoiseField(w, h, scale=w / 2.4, seed=spec.seed ^ 0xF10A, octaves=4)
        warp_y = NoiseField(w, h, scale=w / 2.4, seed=spec.seed ^ 0xF10B, octaves=4)
        base = NoiseField(w, h, scale=w / 1.7, seed=spec.seed ^ 0xF10C, octaves=5)
        stops = list(spec.sky) + [spec.sun]
        strength = w * 0.35
        twist = rng.uniform(8.0, 16.0)
        for y in range(h):
            for x in range(w):
                dx = (warp_x.at(x, y) - 0.5) * strength
                dy = (warp_y.at(x, y) - 0.5) * strength
                v = base.at(x + dx, y + dy)
                v = (v - 0.5) * 1.6 + 0.5  # stretch contrast; raw fBm clusters near 0.5
                t = v + 0.1 * math.sin(v * twist)
                self._put(x, y, _grad(stops, _clamp(t, 0.0, 1.0)))
        # Floating light orbs give the composition a focal point.
        for _ in range(rng.randint(2, 4)):
            cx, cy = rng.randrange(w), rng.randrange(h)
            radius = h * rng.uniform(0.04, 0.11)
            glow = radius * 3
            y0, y1 = max(0, int(cy - glow)), min(h, int(cy + glow) + 1)
            x0, x1 = max(0, int(cx - glow)), min(w, int(cx + glow) + 1)
            for y in range(y0, y1):
                dy2 = (y - cy) ** 2
                for x in range(x0, x1):
                    d = math.sqrt((x - cx) ** 2 + dy2)
                    if d <= radius:
                        self._blend(x, y, spec.sun, 0.85)
                    elif d < glow:
                        self._add(x, y, spec.sun, (1 - (d - radius) / (glow - radius)) ** 2 * 0.25)

    # -- finishing ------------------------------------------------------------

    def _finish(self, style: str = None):
        style = style or getattr(self, "style", "vivid")
        w, h, img = self.w, self.h, self.img
        sat = _STYLE_SATURATION.get(style, 1.0)
        vig_strength = 0.55 if style == "noir" else 0.32
        brightness = 0.88 if style == "noir" else 1.0
        cx, cy = (w - 1) / 2, (h - 1) / 2
        col_d2 = [((x - cx) / cx) ** 2 for x in range(w)]
        row_d2 = [((y - cy) / cy) ** 2 for y in range(h)]
        rnd = self.spec.seed & 0xFFFFFFFF or 1
        i = 0
        for y in range(h):
            ry = row_d2[y]
            for x in range(w):
                vig = (1.0 - vig_strength * (col_d2[x] + ry) * 0.5) * brightness
                r, g, b = img[i], img[i + 1], img[i + 2]
                if sat != 1.0:
                    gray = (r + g + b) / 3.0
                    r = gray + (r - gray) * sat
                    g = gray + (g - gray) * sat
                    b = gray + (b - gray) * sat
                rnd = (rnd * 1664525 + 1013904223) & 0xFFFFFFFF
                grain = ((rnd >> 16) & 7) - 3
                img[i] = _clamp(int(r * vig + grain))
                img[i + 1] = _clamp(int(g * vig + grain))
                img[i + 2] = _clamp(int(b * vig + grain))
                i += 3


def generate(prompt: str, aspect: str = "1:1", style: str = "vivid",
             seed=None, variant: int = 0):
    """Render one image. Returns (png_bytes, width, height, resolved_seed)."""
    width, height = ASPECTS.get(aspect, ASPECTS["1:1"])
    spec = build_spec(prompt, seed=seed, variant=variant)
    renderer = DreamRenderer(spec, width, height)
    renderer.style = style if style in STYLES else "vivid"
    data = renderer.render()
    return data, width, height, spec.seed


MAX_REMIX_PIXELS = 2_000_000


def remix(rgb: bytearray, width: int, height: int, prompt: str,
          style: str = "vivid", seed=None, variant: int = 0,
          strength: float = 0.75):
    """Image-to-image: restyle an input image toward the prompt's palette.

    Luminance is mapped through the prompt-derived gradient and blended with
    the original by `strength` (0 = untouched, 1 = full palette remap), then
    the usual style/grain/vignette finishing runs on top. Deterministic like
    text-to-image. Not diffusion — hosted providers do semantic edits.
    Returns (png_bytes, width, height, resolved_seed).
    """
    if width * height > MAX_REMIX_PIXELS:
        raise ValueError("input image is too large (max 2 megapixels)")
    spec = build_spec(prompt, seed=seed, variant=variant)
    stops = list(spec.sky) + [spec.sun]
    lut = [_grad(stops, v / 255.0) for v in range(256)]
    s = min(1.0, max(0.0, strength))
    img = bytearray(width * height * 3)
    for i in range(0, len(rgb), 3):
        r, g, b = rgb[i], rgb[i + 1], rgb[i + 2]
        cr, cg, cb = lut[(r * 299 + g * 587 + b * 114) // 1000]
        img[i] = int(r + (cr - r) * s)
        img[i + 1] = int(g + (cg - g) * s)
        img[i + 2] = int(b + (cb - b) * s)
    renderer = DreamRenderer(spec, width, height)
    renderer.img = img
    renderer.style = style if style in STYLES else "vivid"
    renderer._finish()
    return png.encode(width, height, img), width, height, spec.seed
