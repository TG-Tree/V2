"""Adapters for image-generation APIs, used when their endpoint/keys are set.

Every adapter has the same signature:

    fn(prompt, n, aspect, image=None, strength=None, style=None, seed=None)

and returns a list of images — each item either raw bytes, or a
(bytes, seed) tuple when the backend reports the seed it actually used.
`image` is a data-URL PNG for image-to-image.

Only the standard library is used; requests go through urllib, which honors
HTTPS_PROXY automatically. The `sd` adapter talks to a *self-hosted*
Stable Diffusion server (AUTOMATIC1111 / SD.Next / Forge `/sdapi/v1` API),
so it is local like `dream` — no cloud, no account, no external policy.
"""

import base64
import json
import os
import time
import urllib.error
import urllib.request

from . import png


class ProviderError(RuntimeError):
    pass


def _post_json(url: str, body: dict, headers: dict, timeout: int = 180) -> dict:
    req = urllib.request.Request(
        url,
        data=json.dumps(body).encode("utf-8"),
        headers={"Content-Type": "application/json", **headers},
        method="POST",
    )
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            return json.load(resp)
    except urllib.error.HTTPError as exc:
        detail = exc.read().decode("utf-8", "replace")[:500]
        raise ProviderError(f"{url} returned HTTP {exc.code}: {detail}") from exc
    except urllib.error.URLError as exc:
        raise ProviderError(f"could not reach {url}: {exc.reason}") from exc


# Optional style tail for models that take style through the prompt
# (dream handles style natively in its renderer).
_STYLE_SUFFIX = {
    "vivid": "vibrant saturated colors, high contrast, rich lighting",
    "muted": "soft muted palette, gentle contrast, restrained color",
    "mono": "black and white monochrome photography",
    "noir": "film noir, dramatic shadows, high-contrast black and white",
}


def _styled_prompt(prompt: str, style: str) -> str:
    suffix = _STYLE_SUFFIX.get(style or "")
    if suffix and suffix.lower() not in prompt.lower():
        return f"{prompt}, {suffix}"
    return prompt


# -- local Stable Diffusion (AUTOMATIC1111-compatible API) ----------------------

# SD checkpoints want dimensions divisible by 8; sized for SDXL-class models.
_SD_SIZES = {
    "1:1": (768, 768),
    "16:9": (1024, 576),
    "9:16": (576, 1024),
    "4:3": (896, 672),
    "3:4": (672, 896),
    "21:9": (1344, 576),
}


def sd_generate(prompt: str, n: int, aspect: str, image=None, strength=None,
                style=None, seed=None) -> list:
    """Self-hosted Stable Diffusion via the A1111 `/sdapi/v1` API.

    Point SD_WEBUI_URL at a running AUTOMATIC1111 / SD.Next / Forge instance
    (e.g. http://127.0.0.1:7860). Fully local: your GPU, your models, your
    rules. Supports txt2img and img2img, and reports the real seeds back so
    results are reproducible.
    """
    base_url = os.environ.get("SD_WEBUI_URL")
    if not base_url:
        raise ProviderError("SD_WEBUI_URL is not set")
    base_url = base_url.rstrip("/")

    n = max(1, min(4, int(n or 1)))
    body = {
        "prompt": _styled_prompt(prompt, style),
        "steps": int(os.environ.get("SD_WEBUI_STEPS", "28")),
        "batch_size": n,
        "seed": int(seed) if seed is not None else -1,
        "send_images": True,
        "save_images": False,
    }
    # User-chosen extras — never imposed by the app.
    negative = os.environ.get("SD_WEBUI_NEGATIVE")
    if negative:
        body["negative_prompt"] = negative
    sampler = os.environ.get("SD_WEBUI_SAMPLER")
    if sampler:
        body["sampler_name"] = sampler
    cfg = os.environ.get("SD_WEBUI_CFG")
    if cfg:
        body["cfg_scale"] = float(cfg)

    if image:
        try:
            b64 = image.split(",", 1)[1]
        except IndexError:
            raise ProviderError("input image must be a data URL")
        # Keep the input's dimensions (rounded to /8) instead of the aspect table.
        dims = png.dimensions(base64.b64decode(b64))
        if dims:
            body["width"] = max(64, dims[0] - dims[0] % 8)
            body["height"] = max(64, dims[1] - dims[1] % 8)
        body["init_images"] = [b64]
        body["denoising_strength"] = strength if strength is not None else 0.75
        endpoint = "/sdapi/v1/img2img"
    else:
        body["width"], body["height"] = _SD_SIZES.get(aspect, _SD_SIZES["1:1"])
        endpoint = "/sdapi/v1/txt2img"

    timeout = int(os.environ.get("SD_WEBUI_TIMEOUT", "600"))
    payload = _post_json(base_url + endpoint, body, {}, timeout=timeout)

    items = payload.get("images") or []
    if not items:
        raise ProviderError("sd webui returned no images")
    # Batches may prepend a grid image depending on webui settings — keep the
    # last n, which are always the individual results.
    if len(items) > n:
        items = items[-n:]

    seeds = []
    try:
        info = json.loads(payload.get("info") or "{}")
        seeds = info.get("all_seeds") or ([info["seed"]] if "seed" in info else [])
    except (ValueError, TypeError, KeyError):
        seeds = []

    out = []
    for i, b64_img in enumerate(items):
        data = base64.b64decode(b64_img)
        out.append((data, seeds[i] if i < len(seeds) else None))
    return out


# -- xAI -------------------------------------------------------------------------

def xai_generate(prompt: str, n: int, aspect: str, image=None, strength=None,
                 style=None, seed=None) -> list:
    """xAI's Grok image API (grok-2-image). Aspect and seed are currently not
    supported by the API, so they are accepted and ignored."""
    key = os.environ.get("XAI_API_KEY")
    if not key:
        raise ProviderError("XAI_API_KEY is not set")
    if image:
        raise ProviderError("the xai provider does not support image input; "
                            "use the dream, sd, or replicate provider for image-to-image")
    base = os.environ.get("XAI_BASE_URL", "https://api.x.ai/v1").rstrip("/")
    payload = _post_json(
        f"{base}/images/generations",
        {
            "model": os.environ.get("XAI_IMAGE_MODEL", "grok-2-image"),
            "prompt": _styled_prompt(prompt, style),
            "n": n,
            "response_format": "b64_json",
        },
        {"Authorization": f"Bearer {key}"},
    )
    return [base64.b64decode(item["b64_json"]) for item in payload["data"]]


# -- OpenAI-compatible (OpenAI, LocalAI, any /v1/images/generations host) --------

_OPENAI_SIZES = {  # closest supported size per aspect
    "1:1": "1024x1024",
    "16:9": "1536x1024",
    "21:9": "1536x1024",
    "4:3": "1536x1024",
    "9:16": "1024x1536",
    "3:4": "1024x1536",
}


def openai_generate(prompt: str, n: int, aspect: str, image=None, strength=None,
                    style=None, seed=None) -> list:
    """OpenAI's image API — or any compatible server (e.g. a self-hosted
    LocalAI) via OPENAI_BASE_URL."""
    key = os.environ.get("OPENAI_API_KEY")
    if not key:
        raise ProviderError("OPENAI_API_KEY is not set")
    if image:
        raise ProviderError("the openai provider is wired for text-to-image only; "
                            "use the dream, sd, or replicate provider for image-to-image")
    base = os.environ.get("OPENAI_BASE_URL", "https://api.openai.com/v1").rstrip("/")
    model = os.environ.get("OPENAI_IMAGE_MODEL", "gpt-image-1")
    body = {
        "model": model,
        "prompt": _styled_prompt(prompt, style),
        "n": n,
        "size": _OPENAI_SIZES.get(aspect, "1024x1024"),
    }
    if model.startswith("dall-e"):
        body["response_format"] = "b64_json"  # gpt-image-1 rejects this param
    payload = _post_json(f"{base}/images/generations", body,
                         {"Authorization": f"Bearer {key}"})
    images = []
    for item in payload["data"]:
        if item.get("b64_json"):
            images.append(base64.b64decode(item["b64_json"]))
        elif item.get("url"):
            images.extend(_download_urls([item["url"]]))
        else:
            raise ProviderError("image API response had neither b64_json nor url")
    return images


# -- Replicate --------------------------------------------------------------------

# Aspect ratios common across Flux hosts. flux-2-max rejects 21:9 — map it.
_REPLICATE_ASPECTS = {"1:1", "16:9", "9:16", "4:3", "3:4", "3:2", "2:3", "4:5", "5:4"}
_REPLICATE_ASPECT_FALLBACK = {"21:9": "16:9"}

# Official Pro/Max models only emit one image per prediction (no num_outputs).
_REPLICATE_SINGLE_SHOT = (
    "flux-1.1-pro", "flux-1.1-pro-ultra", "flux-pro", "flux-kontext-pro",
    "flux-kontext-max", "flux-2-pro", "flux-2-flex", "flux-2-max", "flux-2-dev",
)


def _replicate_model_name(model: str) -> str:
    return model.rsplit("/", 1)[-1].lower()


def _replicate_is_single_shot(model: str) -> bool:
    name = _replicate_model_name(model)
    return any(tag in name for tag in _REPLICATE_SINGLE_SHOT)


def _replicate_run(token: str, model: str, inputs: dict) -> list:
    """Create one prediction and return a list of output image URLs."""
    headers = {"Authorization": f"Bearer {token}", "Prefer": "wait"}
    prediction = _post_json(
        f"https://api.replicate.com/v1/models/{model}/predictions",
        {"input": inputs}, headers,
    )

    # "Prefer: wait" blocks up to ~60s; poll if the model is still running.
    deadline = time.time() + int(os.environ.get("REPLICATE_TIMEOUT", "180"))
    while prediction.get("status") in ("starting", "processing"):
        if time.time() > deadline:
            raise ProviderError(f"replicate prediction timed out ({model})")
        time.sleep(2)
        req = urllib.request.Request(prediction["urls"]["get"],
                                     headers={"Authorization": f"Bearer {token}"})
        with urllib.request.urlopen(req, timeout=30) as resp:
            prediction = json.load(resp)
    if prediction.get("status") != "succeeded":
        detail = str(prediction.get("error") or prediction.get("status"))[:300]
        raise ProviderError(f"replicate prediction failed: {detail}")

    outputs = prediction.get("output") or []
    if isinstance(outputs, str):
        outputs = [outputs]
    if not outputs:
        raise ProviderError("replicate returned no images")
    return outputs


def _download_urls(urls: list) -> list:
    images = []
    for url in urls:
        with urllib.request.urlopen(url, timeout=120) as resp:
            images.append(resp.read())
    return images


def replicate_generate(prompt: str, n: int, aspect: str, image=None, strength=None,
                       style=None, seed=None) -> list:
    """Replicate-hosted diffusion (FLUX.2 Max by default; any model via env).

    Text-to-image uses REPLICATE_MODEL (default black-forest-labs/flux-2-max);
    image-to-image uses REPLICATE_IMG2IMG_MODEL (default black-forest-labs/flux-dev),
    with the data-URL input passed as `image` and strength as `prompt_strength`.

    Schnell is the cheap draft model — Max/Pro are for final quality.
    """
    token = os.environ.get("REPLICATE_API_TOKEN")
    if not token:
        raise ProviderError("REPLICATE_API_TOKEN is not set")
    if image:
        model = os.environ.get("REPLICATE_IMG2IMG_MODEL", "black-forest-labs/flux-dev")
    else:
        model = os.environ.get("REPLICATE_MODEL", "black-forest-labs/flux-2-max")

    quality = int(os.environ.get("REPLICATE_OUTPUT_QUALITY", "100"))
    quality = max(1, min(100, quality))
    upsample = os.environ.get("REPLICATE_PROMPT_UPSAMPLING", "true").lower()
    upsample = upsample in ("1", "true", "yes", "on")

    base = {
        "prompt": _styled_prompt(prompt, style),
        "output_format": os.environ.get("REPLICATE_OUTPUT_FORMAT", "png"),
        "output_quality": quality,
        "safety_tolerance": int(os.environ.get("REPLICATE_SAFETY_TOLERANCE", "5")),
    }
    if upsample:
        base["prompt_upsampling"] = True
    ratio = _REPLICATE_ASPECT_FALLBACK.get(aspect, aspect)
    if ratio in _REPLICATE_ASPECTS:
        base["aspect_ratio"] = ratio
    if image:
        base["image"] = image
        base["prompt_strength"] = strength if strength is not None else 0.8

    n = max(1, min(4, int(n or 1)))
    urls = []
    if _replicate_is_single_shot(model) or n == 1:
        # Pro / ultra / kontext: one image per call — loop for n variants.
        for _ in range(n):
            urls.extend(_replicate_run(token, model, dict(base)))
    else:
        inputs = dict(base)
        inputs["num_outputs"] = n
        urls.extend(_replicate_run(token, model, inputs))
    return _download_urls(urls)


# -- registry ---------------------------------------------------------------------

def _sd_detail():
    return os.environ.get("SD_WEBUI_URL", "")


def _model_detail(env, default):
    return lambda: os.environ.get(env, default)


# Order matters: the first *configured* entry becomes the default provider,
# so a local SD server outranks the hosted APIs (local-first by design).
PROVIDERS = {
    "sd": {
        "fn": sd_generate,
        "env": "SD_WEBUI_URL",
        "label": "stable diffusion (local)",
        "local": True,
        "img2img": True,
        "seed": True,
        "detail": _sd_detail,
    },
    "replicate": {
        "fn": replicate_generate,
        "env": "REPLICATE_API_TOKEN",
        "label": "replicate (Flux)",
        "local": False,
        "img2img": True,
        "seed": False,
        "detail": _model_detail("REPLICATE_MODEL", "black-forest-labs/flux-2-max"),
    },
    "xai": {
        "fn": xai_generate,
        "env": "XAI_API_KEY",
        "label": "xai (Imagine)",
        "local": False,
        "img2img": False,
        "seed": False,
        "detail": _model_detail("XAI_IMAGE_MODEL", "grok-2-image"),
    },
    "openai": {
        "fn": openai_generate,
        "env": "OPENAI_API_KEY",
        "label": "openai",
        "local": False,
        "img2img": False,
        "seed": False,
        "detail": _model_detail("OPENAI_IMAGE_MODEL", "gpt-image-1"),
    },
}


def provider_info() -> list:
    """Capability metadata for every adapter, availability included."""
    infos = []
    for name, meta in PROVIDERS.items():
        infos.append({
            "name": name,
            "label": meta["label"],
            "local": meta["local"],
            "img2img": meta["img2img"],
            "seed": meta["seed"],
            "available": bool(os.environ.get(meta["env"])),
            "detail": meta["detail"](),
        })
    return infos


def available_remote_providers() -> list:
    return [name for name, meta in PROVIDERS.items() if os.environ.get(meta["env"])]
