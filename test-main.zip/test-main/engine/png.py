"""Minimal PNG encoder/decoder (8-bit) using only the standard library.

The decoder handles what browsers emit from canvas.toDataURL("image/png")
— 8-bit gray/RGB/RGBA, non-interlaced, all five scanline filters — which is
the only path uploads take (the client converts every format to PNG first).
"""

import struct
import zlib


def encode(width: int, height: int, rgb: bytearray) -> bytes:
    """Encode a flat RGB buffer (len == width * height * 3) as PNG bytes."""
    if len(rgb) != width * height * 3:
        raise ValueError("buffer size does not match dimensions")

    stride = width * 3
    raw = bytearray()
    for y in range(height):
        raw.append(0)  # filter type 0 (None) per scanline
        raw += rgb[y * stride:(y + 1) * stride]

    return b"".join([
        _SIGNATURE,
        _chunk(b"IHDR", struct.pack(">IIBBBBB", width, height, 8, 2, 0, 0, 0)),
        _chunk(b"IDAT", zlib.compress(bytes(raw), 6)),
        _chunk(b"IEND", b""),
    ])


_SIGNATURE = b"\x89PNG\r\n\x1a\n"


def _chunk(tag: bytes, data: bytes) -> bytes:
    block = tag + data
    return (
        struct.pack(">I", len(data))
        + block
        + struct.pack(">I", zlib.crc32(block) & 0xFFFFFFFF)
    )


def dimensions(data: bytes):
    """Read (width, height) from a PNG's IHDR, or None if not a PNG."""
    if data[:8] != _SIGNATURE or data[12:16] != b"IHDR" or len(data) < 24:
        return None
    return struct.unpack(">II", data[16:24])


def add_metadata(data: bytes, pairs: dict) -> bytes:
    """Insert iTXt chunks (UTF-8 key/value text) right after IHDR.

    Non-PNG input is returned unchanged. Used to embed the generation recipe
    (prompt, seed, provider, …) so downloaded files are self-documenting.
    """
    if data[:8] != _SIGNATURE or data[12:16] != b"IHDR":
        return data
    ihdr_len = struct.unpack(">I", data[8:12])[0]
    insert_at = 8 + 12 + ihdr_len
    chunks = b""
    for key, value in pairs.items():
        if value is None:
            continue
        # iTXt: keyword\0 compressed(0) method(0) language\0 translated\0 text
        payload = key.encode("latin-1") + b"\x00\x00\x00\x00\x00" + str(value).encode("utf-8")
        chunks += _chunk(b"iTXt", payload)
    return data[:insert_at] + chunks + data[insert_at:]


def read_metadata(data: bytes) -> dict:
    """Extract iTXt/tEXt key/value pairs from a PNG."""
    out = {}
    if data[:8] != _SIGNATURE:
        return out
    pos = 8
    while pos + 8 <= len(data):
        length = struct.unpack(">I", data[pos:pos + 4])[0]
        tag = data[pos + 4:pos + 8]
        chunk = data[pos + 8:pos + 8 + length]
        pos += 12 + length
        if tag == b"iTXt":
            head, _, rest = chunk.partition(b"\x00")
            if len(rest) >= 2 and rest[0] == 0:  # uncompressed only
                # skip flag+method bytes, then language and translated-keyword
                fields = rest[2:].split(b"\x00", 2)
                if len(fields) == 3:
                    out[head.decode("latin-1")] = fields[2].decode("utf-8", "replace")
        elif tag == b"tEXt":
            key, _, text = chunk.partition(b"\x00")
            out[key.decode("latin-1")] = text.decode("latin-1")
        elif tag == b"IEND":
            break
    return out


def _paeth(a, b, c):
    p = a + b - c
    pa, pb, pc = abs(p - a), abs(p - b), abs(p - c)
    if pa <= pb and pa <= pc:
        return a
    return b if pb <= pc else c


def decode(data: bytes):
    """Decode a PNG into (width, height, flat RGB bytearray)."""
    if data[:8] != b"\x89PNG\r\n\x1a\n":
        raise ValueError("not a PNG file")
    pos, idat = 8, b""
    width = height = channels = None
    while pos + 8 <= len(data):
        length = struct.unpack(">I", data[pos:pos + 4])[0]
        tag = data[pos + 4:pos + 8]
        chunk = data[pos + 8:pos + 8 + length]
        pos += 12 + length
        if tag == b"IHDR":
            width, height, depth, ctype, _, _, interlace = struct.unpack(">IIBBBBB", chunk)
            if depth != 8 or interlace != 0 or ctype not in (0, 2, 6):
                raise ValueError("unsupported PNG variant (need 8-bit gray/RGB/RGBA, non-interlaced)")
            channels = {0: 1, 2: 3, 6: 4}[ctype]
        elif tag == b"IDAT":
            idat += chunk
        elif tag == b"IEND":
            break
    if width is None or not idat:
        raise ValueError("truncated PNG")

    raw = zlib.decompress(idat)
    stride = width * channels
    if len(raw) < (stride + 1) * height:
        raise ValueError("truncated PNG data")
    out = bytearray(width * height * 3)
    prev = bytearray(stride)
    pos = 0
    for y in range(height):
        ftype = raw[pos]
        line = bytearray(raw[pos + 1:pos + 1 + stride])
        pos += 1 + stride
        if ftype == 1:    # Sub
            for i in range(channels, stride):
                line[i] = (line[i] + line[i - channels]) & 0xFF
        elif ftype == 2:  # Up
            for i in range(stride):
                line[i] = (line[i] + prev[i]) & 0xFF
        elif ftype == 3:  # Average
            for i in range(stride):
                left = line[i - channels] if i >= channels else 0
                line[i] = (line[i] + (left + prev[i]) // 2) & 0xFF
        elif ftype == 4:  # Paeth
            for i in range(stride):
                left = line[i - channels] if i >= channels else 0
                ul = prev[i - channels] if i >= channels else 0
                line[i] = (line[i] + _paeth(left, prev[i], ul)) & 0xFF
        elif ftype != 0:
            raise ValueError(f"bad PNG filter type {ftype}")
        prev = line
        o = y * width * 3
        if channels == 1:
            for x in range(width):
                v = line[x]
                out[o] = out[o + 1] = out[o + 2] = v
                o += 3
        elif channels == 3:
            out[o:o + stride] = line
        else:  # RGBA: alpha is dropped (uploads are photos; canvas fills opaque)
            for x in range(width):
                i = x * 4
                out[o] = line[i]
                out[o + 1] = line[i + 1]
                out[o + 2] = line[i + 2]
                o += 3
    return width, height, out
