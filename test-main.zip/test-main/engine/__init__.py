"""Imagine Engine — a self-hosted, dependency-free text-to-image studio."""

__version__ = "0.1.0"
