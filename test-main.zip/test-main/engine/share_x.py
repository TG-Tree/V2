"""Share to X (Twitter): stdlib OAuth 1.0a + OAuth 2.0 user-context posting.

Posting needs *user context* (not the app-only bearer). Two paths:

1. **OAuth 2.0** (preferred when present): X_CLIENT_ID + user access token
   (X_OAUTH2_ACCESS_TOKEN). Optional X_OAUTH2_REFRESH_TOKEN + X_CLIENT_SECRET
   refresh expired access tokens. Media upload + create post use Bearer auth.
2. **OAuth 1.0a**: X_CONSUMER_KEY / X_CONSUMER_SECRET + access token pair
   (env or PIN flow → `.x_session.json`).

An app-only X_BEARER_TOKEN cannot create posts.
"""

import base64
import hashlib
import hmac
import json
import os
import secrets
import time
import urllib.error
import urllib.parse
import urllib.request
import uuid

API = "https://api.x.com"
UPLOAD_V1 = "https://upload.twitter.com/1.1/media/upload.json"
TOKEN_URL = f"{API}/2/oauth2/token"
POST_CHAR_LIMIT = 280

_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
SESSION_PATH = os.environ.get("X_SESSION_FILE",
                              os.path.join(_ROOT, ".x_session.json"))
OAUTH2_SESSION_PATH = os.environ.get(
    "X_OAUTH2_SESSION_FILE", os.path.join(_ROOT, ".x_oauth2_session.json"))

# PIN-flow request tokens awaiting verification: oauth_token -> token secret.
_pending = {}


class XError(RuntimeError):
    def __init__(self, message, code=None):
        super().__init__(message)
        self.code = code


# -- OAuth 1.0a signing --------------------------------------------------------

def _enc(value) -> str:
    return urllib.parse.quote(str(value), safe="")


def _sign(method: str, url: str, params: dict, consumer_secret: str,
          token_secret: str = "") -> str:
    pairs = sorted((_enc(k), _enc(v)) for k, v in params.items())
    param_string = "&".join(f"{k}={v}" for k, v in pairs)
    base = "&".join((method.upper(), _enc(url), _enc(param_string)))
    key = f"{_enc(consumer_secret)}&{_enc(token_secret)}"
    digest = hmac.new(key.encode(), base.encode(), hashlib.sha1).digest()
    return base64.b64encode(digest).decode()


def _consumer():
    key = os.environ.get("X_CONSUMER_KEY")
    secret = os.environ.get("X_CONSUMER_SECRET")
    if not key or not secret:
        raise XError("X_CONSUMER_KEY / X_CONSUMER_SECRET are not set")
    return key, secret


def _oauth_header(method: str, url: str, token: str = "",
                  token_secret: str = "", extra: dict = None) -> str:
    """Build an Authorization header. `extra` holds additional oauth_*
    protocol params (callback / verifier); JSON and multipart bodies are not
    part of the signature base string, so no body params are ever included."""
    key, consumer_secret = _consumer()
    oauth = {
        "oauth_consumer_key": key,
        "oauth_nonce": secrets.token_hex(16),
        "oauth_signature_method": "HMAC-SHA1",
        "oauth_timestamp": str(int(time.time())),
        "oauth_version": "1.0",
    }
    if token:
        oauth["oauth_token"] = token
    if extra:
        oauth.update(extra)
    oauth["oauth_signature"] = _sign(method, url, oauth, consumer_secret,
                                     token_secret)
    return "OAuth " + ", ".join(f'{_enc(k)}="{_enc(v)}"'
                                for k, v in sorted(oauth.items()))


def _request(method: str, url: str, headers: dict, data: bytes = None,
             timeout: int = 30) -> bytes:
    req = urllib.request.Request(url, data=data, headers=headers, method=method)
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            return resp.read()
    except urllib.error.HTTPError as exc:
        detail = exc.read().decode("utf-8", "replace")[:400]
        raise XError(f"X returned HTTP {exc.code} for {url.split('?')[0]}: "
                     f"{detail}", code=exc.code) from exc
    except urllib.error.URLError as exc:
        raise XError(f"could not reach X: {exc.reason}") from exc


# -- OAuth 2.0 user tokens -----------------------------------------------------

def _oauth2_from_env():
    access = os.environ.get("X_OAUTH2_ACCESS_TOKEN")
    refresh = os.environ.get("X_OAUTH2_REFRESH_TOKEN")
    if access:
        return {"access_token": access, "refresh_token": refresh,
                "handle": os.environ.get("X_HANDLE")}
    return None


def _oauth2_from_file():
    try:
        with open(OAUTH2_SESSION_PATH, "r", encoding="utf-8") as fh:
            data = json.load(fh)
        if data.get("access_token"):
            return data
    except (OSError, json.JSONDecodeError, TypeError):
        pass
    return None


def _oauth2_session():
    return _oauth2_from_env() or _oauth2_from_file()


def _save_oauth2_session(access: str, refresh: str = None, handle: str = None):
    prev = _oauth2_from_file() or {}
    data = {
        "access_token": access,
        "refresh_token": refresh or prev.get("refresh_token"),
        "handle": handle or prev.get("handle"),
    }
    with open(OAUTH2_SESSION_PATH, "w", encoding="utf-8") as fh:
        json.dump(data, fh)
    # Keep process env in sync for the rest of this run.
    os.environ["X_OAUTH2_ACCESS_TOKEN"] = access
    if data.get("refresh_token"):
        os.environ["X_OAUTH2_REFRESH_TOKEN"] = data["refresh_token"]


def _oauth2_refresh() -> str:
    """Exchange refresh token for a new access token; returns access token."""
    sess = _oauth2_session() or {}
    refresh = (sess.get("refresh_token")
               or os.environ.get("X_OAUTH2_REFRESH_TOKEN"))
    client_id = os.environ.get("X_CLIENT_ID")
    client_secret = os.environ.get("X_CLIENT_SECRET")
    if not refresh or not client_id:
        raise XError("OAuth 2.0 access token expired and no refresh credentials")

    body = urllib.parse.urlencode({
        "grant_type": "refresh_token",
        "refresh_token": refresh,
        "client_id": client_id,
    }).encode("utf-8")
    headers = {"Content-Type": "application/x-www-form-urlencoded"}
    if client_secret:
        basic = base64.b64encode(
            f"{client_id}:{client_secret}".encode()).decode()
        headers["Authorization"] = f"Basic {basic}"

    raw = _request("POST", TOKEN_URL, headers, body, timeout=30)
    data = json.loads(raw)
    access = data.get("access_token")
    if not access:
        raise XError(f"token refresh failed: {str(data)[:200]}")
    _save_oauth2_session(access, data.get("refresh_token") or refresh,
                         sess.get("handle"))
    return access


def _oauth2_bearer() -> str:
    sess = _oauth2_session()
    if not sess:
        raise XError("no OAuth 2.0 access token")
    return sess["access_token"]


def _oauth2_request(method: str, url: str, headers: dict = None,
                    data: bytes = None, timeout: int = 60) -> bytes:
    """Bearer request; on 401, refresh once and retry."""
    headers = dict(headers or {})
    headers["Authorization"] = f"Bearer {_oauth2_bearer()}"
    try:
        return _request(method, url, headers, data, timeout=timeout)
    except XError as exc:
        if exc.code != 401:
            raise
        headers["Authorization"] = f"Bearer {_oauth2_refresh()}"
        return _request(method, url, headers, data, timeout=timeout)


def _oauth2_me_handle() -> str:
    try:
        raw = _oauth2_request("GET", f"{API}/2/users/me")
        data = json.loads(raw)
        return (data.get("data") or {}).get("username")
    except XError:
        return None


# -- account state --------------------------------------------------------------

def configured() -> bool:
    oauth2 = bool(os.environ.get("X_CLIENT_ID")
                  and (_oauth2_session() or os.environ.get("X_OAUTH2_ACCESS_TOKEN")))
    oauth1 = bool(os.environ.get("X_CONSUMER_KEY")
                  and os.environ.get("X_CONSUMER_SECRET"))
    return oauth2 or oauth1


def _session_oauth1():
    """(token, token_secret, handle) for OAuth 1.0a, or None."""
    token = os.environ.get("X_ACCESS_TOKEN")
    secret = os.environ.get("X_ACCESS_TOKEN_SECRET")
    if token and secret:
        return token, secret, os.environ.get("X_HANDLE")
    try:
        with open(SESSION_PATH, "r", encoding="utf-8") as fh:
            data = json.load(fh)
        return data["token"], data["secret"], data.get("handle")
    except (OSError, json.JSONDecodeError, KeyError):
        return None


def status() -> dict:
    o1 = _session_oauth1() if (os.environ.get("X_CONSUMER_KEY")
                               and os.environ.get("X_CONSUMER_SECRET")) else None
    if o1:
        handle = o1[2] or os.environ.get("X_HANDLE")
        return {
            "configured": True,
            "connected": True,
            "handle": handle,
            "auth": "oauth1",
        }
    o2 = _oauth2_session()
    if o2:
        handle = o2.get("handle") or os.environ.get("X_HANDLE")
        if not handle:
            try:
                handle = _oauth2_me_handle()
                if handle:
                    _save_oauth2_session(
                        o2["access_token"], o2.get("refresh_token"), handle)
            except XError:
                handle = None
        return {
            "configured": True,
            "connected": True,
            "handle": handle,
            "auth": "oauth2",
        }
    return {
        "configured": configured(),
        "connected": False,
        "handle": None,
        "auth": None,
    }


# -- PIN (out-of-band) connect flow — OAuth 1.0a only ---------------------------

def begin_connect() -> dict:
    if _oauth2_session():
        raise XError("already connected via OAuth 2.0 tokens in .env — "
                     "no PIN flow needed")
    url = f"{API}/oauth/request_token"
    header = _oauth_header("POST", url, extra={"oauth_callback": "oob"})
    body = _request("POST", url, {"Authorization": header}, data=b"")
    fields = dict(urllib.parse.parse_qsl(body.decode("utf-8", "replace")))
    token = fields.get("oauth_token")
    if not token:
        raise XError(f"unexpected request_token response: {body[:200]!r}")
    _pending[token] = fields.get("oauth_token_secret", "")
    while len(_pending) > 8:  # single-user app; drop stale attempts
        _pending.pop(next(iter(_pending)))
    return {
        "authorize_url": f"{API}/oauth/authorize?oauth_token={_enc(token)}",
        "oauth_token": token,
    }


def finish_connect(pin: str, oauth_token: str = None) -> dict:
    if not _pending:
        raise XError("no pending authorization — start the connect step first")
    token = oauth_token if oauth_token in _pending else next(reversed(_pending))
    url = f"{API}/oauth/access_token"
    header = _oauth_header("POST", url, token=token,
                           token_secret=_pending[token],
                           extra={"oauth_verifier": pin.strip()})
    body = _request("POST", url, {"Authorization": header}, data=b"")
    fields = dict(urllib.parse.parse_qsl(body.decode("utf-8", "replace")))
    access, access_secret = (fields.get("oauth_token"),
                             fields.get("oauth_token_secret"))
    if not access or not access_secret:
        raise XError(f"unexpected access_token response: {body[:200]!r}")
    handle = fields.get("screen_name")
    with open(SESSION_PATH, "w", encoding="utf-8") as fh:
        json.dump({"token": access, "secret": access_secret,
                   "handle": handle}, fh)
    _pending.clear()
    return {"handle": handle}


def disconnect():
    for path in (SESSION_PATH, OAUTH2_SESSION_PATH):
        try:
            os.remove(path)
        except FileNotFoundError:
            pass
    for key in ("X_OAUTH2_ACCESS_TOKEN", "X_OAUTH2_REFRESH_TOKEN",
                "X_ACCESS_TOKEN", "X_ACCESS_TOKEN_SECRET"):
        os.environ.pop(key, None)


# -- posting ---------------------------------------------------------------------

def _multipart(fields: dict, files: dict) -> tuple:
    """Build (body, content_type) for multipart/form-data.
    files: name -> (filename, bytes, content_type)."""
    boundary = uuid.uuid4().hex
    parts = []
    for name, value in fields.items():
        parts.append(
            f"--{boundary}\r\n"
            f'Content-Disposition: form-data; name="{name}"\r\n\r\n'
            f"{value}\r\n".encode()
        )
    for name, (filename, data, ctype) in files.items():
        parts.append(
            f"--{boundary}\r\n"
            f'Content-Disposition: form-data; name="{name}"; '
            f'filename="{filename}"\r\n'
            f"Content-Type: {ctype}\r\n\r\n".encode()
        )
        parts.append(data)
        parts.append(b"\r\n")
    parts.append(f"--{boundary}--\r\n".encode())
    return b"".join(parts), f"multipart/form-data; boundary={boundary}"


def _upload_media_oauth1(image: bytes, token: str, token_secret: str) -> str:
    # Prefer v1.1 simple upload (OAuth 1.0a classic). Fall back to v2 with
    # required media_category.
    body_v1, ctype_v1 = _multipart({}, {
        "media": ("imagine.png", image, "image/png"),
    })

    def headers(url, ctype):
        return {
            "Authorization": _oauth_header("POST", url, token, token_secret),
            "Content-Type": ctype,
        }

    try:
        payload = json.loads(_request(
            "POST", UPLOAD_V1, headers(UPLOAD_V1, ctype_v1), body_v1,
            timeout=60))
        return _media_id_from_payload(payload)
    except XError as exc:
        if exc.code not in (403, 404, 410, 400):
            raise

    body_v2, ctype_v2 = _multipart(
        {"media_category": "tweet_image"},
        {"media": ("imagine.png", image, "image/png")},
    )
    v2 = f"{API}/2/media/upload"
    payload = json.loads(_request(
        "POST", v2, headers(v2, ctype_v2), body_v2, timeout=60))
    return _media_id_from_payload(payload)


def _upload_media_oauth2(image: bytes) -> str:
    boundary = uuid.uuid4().hex
    body = b"".join([
        f"--{boundary}\r\n".encode(),
        b'Content-Disposition: form-data; name="media"; '
        b'filename="imagine.png"\r\n',
        b"Content-Type: application/octet-stream\r\n\r\n",
        image,
        f"\r\n--{boundary}--\r\n".encode(),
    ])
    headers = {
        "Content-Type": f"multipart/form-data; boundary={boundary}",
    }
    v2 = f"{API}/2/media/upload"
    try:
        payload = json.loads(_oauth2_request("POST", v2, headers, body,
                                             timeout=60))
    except XError as exc:
        # Some plans only allow v1.1 upload with OAuth 1.0a.
        if exc.code in (403, 404, 410):
            raise XError(
                "media upload failed under OAuth 2.0 (need media.write scope, "
                f"or use OAuth 1.0a PIN connect): {exc}",
                code=exc.code) from exc
        raise
    return _media_id_from_payload(payload)


def _media_id_from_payload(payload: dict) -> str:
    data = payload.get("data", payload)
    media_id = (data.get("id") or data.get("media_id_string")
                or data.get("media_id"))
    if not media_id:
        raise XError(f"media upload returned no id: {str(payload)[:200]}")
    return str(media_id)


def share(image: bytes, text: str) -> dict:
    """Upload `image` and create a post with `text`; returns {id, url}.

    Prefers OAuth 1.0a when present — media upload often needs it because
    OAuth 2.0 requires an explicit media.write scope many apps never grant.
    """
    text = (text or "").strip()
    if not text:
        raise XError("post text is required")
    if len(text) > POST_CHAR_LIMIT:
        raise XError(f"post text is over {POST_CHAR_LIMIT} characters")

    # Prefer OAuth 1.0a for media+post (works with portal Read+Write user tokens).
    sess = _session_oauth1()
    if sess:
        token, token_secret, handle = sess
        media_id = _upload_media_oauth1(image, token, token_secret)
        url = f"{API}/2/tweets"
        resp = json.loads(_request("POST", url, {
            "Authorization": _oauth_header("POST", url, token, token_secret),
            "Content-Type": "application/json",
        }, json.dumps({"text": text,
                       "media": {"media_ids": [media_id]}}).encode("utf-8"),
            timeout=60))
    else:
        o2 = _oauth2_session()
        if not o2:
            raise XError("no X account connected")
        handle = o2.get("handle") or _oauth2_me_handle()
        if handle and not o2.get("handle"):
            _save_oauth2_session(o2["access_token"], o2.get("refresh_token"),
                                 handle)
        media_id = _upload_media_oauth2(image)
        url = f"{API}/2/tweets"
        resp = json.loads(_oauth2_request("POST", url, {
            "Content-Type": "application/json",
        }, json.dumps({"text": text,
                       "media": {"media_ids": [media_id]}}).encode("utf-8"),
            timeout=60))

    post_id = (resp.get("data") or {}).get("id")
    if not post_id:
        raise XError(f"unexpected create-post response: {str(resp)[:200]}")
    post_url = (f"https://x.com/{handle}/status/{post_id}" if handle
                else f"https://x.com/i/web/status/{post_id}")
    return {"id": post_id, "url": post_url}
