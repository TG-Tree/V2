"""Seeded value noise and fBm, sampled on a coarse grid for speed."""

import math
import random


class ValueNoise:
    """Classic lattice value noise with smoothstep interpolation."""

    def __init__(self, seed: int):
        rnd = random.Random(seed)
        perm = list(range(256))
        rnd.shuffle(perm)
        self.perm = perm + perm

    def _lattice(self, xi: int, yi: int) -> float:
        return self.perm[(self.perm[xi & 255] + yi) & 255] / 255.0

    def sample(self, x: float, y: float) -> float:
        xi, yi = math.floor(x), math.floor(y)
        fx, fy = x - xi, y - yi
        u = fx * fx * (3.0 - 2.0 * fx)
        v = fy * fy * (3.0 - 2.0 * fy)
        a = self._lattice(xi, yi)
        b = self._lattice(xi + 1, yi)
        c = self._lattice(xi, yi + 1)
        d = self._lattice(xi + 1, yi + 1)
        top = a + (b - a) * u
        bot = c + (d - c) * u
        return top + (bot - top) * v

    def fbm(self, x: float, y: float, octaves: int = 4,
            lacunarity: float = 2.0, gain: float = 0.5) -> float:
        total, norm, amp, freq = 0.0, 0.0, 1.0, 1.0
        for _ in range(octaves):
            total += amp * self.sample(x * freq, y * freq)
            norm += amp
            amp *= gain
            freq *= lacunarity
        return total / norm


class NoiseField:
    """fBm evaluated every `step` pixels and bilinearly interpolated between.

    Pure-Python per-pixel fBm is too slow for full frames; a 4px lattice is
    visually indistinguishable for clouds/nebulae and ~16x faster.
    """

    def __init__(self, width: int, height: int, scale: float, seed: int,
                 octaves: int = 4, step: int = 4):
        self.step = step
        self.cols = width // step + 2
        self.rows = height // step + 2
        noise = ValueNoise(seed)
        s = step / scale
        self.grid = [
            noise.fbm(cx * s, cy * s, octaves)
            for cy in range(self.rows)
            for cx in range(self.cols)
        ]

    def at(self, x: float, y: float) -> float:
        gx, gy = x / self.step, y / self.step
        xi, yi = int(gx), int(gy)
        if xi < 0:
            xi = 0
        elif xi > self.cols - 2:
            xi = self.cols - 2
        if yi < 0:
            yi = 0
        elif yi > self.rows - 2:
            yi = self.rows - 2
        fx, fy = gx - xi, gy - yi
        # Smoothstep the weights: plain bilinear leaves derivative
        # discontinuities at cell edges that read as faint grid lines.
        fx = fx * fx * (3.0 - 2.0 * fx)
        fy = fy * fy * (3.0 - 2.0 * fy)
        g = self.grid
        i = yi * self.cols + xi
        top = g[i] + (g[i + 1] - g[i]) * fx
        j = i + self.cols
        bot = g[j] + (g[j + 1] - g[j]) * fx
        return top + (bot - top) * fy


def ridgeline(rng: random.Random, width: int, roughness: float) -> list:
    """1D midpoint-displacement ridge, normalized to 0..1, one value per column."""
    n = 1 << max(4, (width - 1).bit_length())
    pts = [0.0] * (n + 1)
    pts[0] = rng.uniform(0.25, 0.75)
    pts[n] = rng.uniform(0.25, 0.75)
    step, disp = n, 1.0
    while step > 1:
        half = step // 2
        for i in range(half, n, step):
            pts[i] = (pts[i - half] + pts[i + half]) / 2.0 + rng.uniform(-1, 1) * disp * roughness
        step = half
        disp *= 0.55
    lo, hi = min(pts), max(pts)
    span = (hi - lo) or 1.0
    return [(p - lo) / span for p in pts[:width]]
