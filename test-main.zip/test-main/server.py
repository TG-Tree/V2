#!/usr/bin/env python3
"""Imagine Engine — a self-hosted, Grok-Imagine-style text-to-image studio.

Run `python3 server.py` and open http://localhost:8000. No dependencies.
"""

import argparse
import json
import mimetypes
import os
import random
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import parse_qs

from engine.core import ImagineEngine
from engine.dream import ASPECTS, STYLES
from engine.prompt import SURPRISE_PROMPTS
from engine.providers import ProviderError
from engine import share_x

ROOT = os.path.dirname(os.path.abspath(__file__))
WEB_DIR = os.path.join(ROOT, "web")
OUT_DIR = os.path.join(ROOT, "generated")

MAX_PROMPT_LENGTH = 2000
MAX_IMAGES_PER_REQUEST = 4
MAX_BODY_BYTES = 24 * 1024 * 1024  # data-URL uploads included
MAX_SHARE_TEXT = share_x.POST_CHAR_LIMIT


def _load_dotenv(path=None):
    """Load KEY=VALUE pairs from a local .env into os.environ (no overwrite)."""
    path = path or os.path.join(ROOT, ".env")
    try:
        with open(path, "r", encoding="utf-8") as fh:
            lines = fh.readlines()
    except OSError:
        return
    for raw in lines:
        line = raw.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, _, value = line.partition("=")
        key = key.strip()
        value = value.strip().strip("'").strip('"')
        if key and key not in os.environ:
            os.environ[key] = value


_load_dotenv()
engine = ImagineEngine(OUT_DIR)


class Handler(BaseHTTPRequestHandler):
    protocol_version = "HTTP/1.1"

    # -- helpers ---------------------------------------------------------------

    def _send_json(self, payload, status=200):
        body = json.dumps(payload).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def _send_file(self, directory, name):
        # Only plain basenames are ever served, so traversal is impossible.
        if name != os.path.basename(name) or name.startswith("."):
            return self._send_json({"error": "not found"}, 404)
        path = os.path.join(directory, name)
        if not os.path.isfile(path):
            return self._send_json({"error": "not found"}, 404)
        ctype = mimetypes.guess_type(path)[0] or "application/octet-stream"
        with open(path, "rb") as fh:
            body = fh.read()
        self.send_response(200)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(body)))
        if directory == OUT_DIR:
            self.send_header("Cache-Control", "public, max-age=31536000, immutable")
        self.end_headers()
        self.wfile.write(body)

    def log_message(self, fmt, *args):
        pass  # keep the console quiet; errors surface via JSON responses

    # -- routes -----------------------------------------------------------------

    def _read_json_body(self):
        try:
            length = int(self.headers.get("Content-Length", 0))
        except ValueError:
            length = 0
        if length > MAX_BODY_BYTES:
            self._send_json({"error": "request body too large"}, 413)
            return None
        try:
            return json.loads(self.rfile.read(length) or b"{}")
        except (ValueError, json.JSONDecodeError):
            self._send_json({"error": "invalid JSON body"}, 400)
            return None

    def _image_bytes(self, image_id: str):
        """Resolve a gallery image id to raw file bytes, or None."""
        if not image_id or image_id != os.path.basename(image_id):
            return None
        for name in (f"{image_id}.png", f"{image_id}.jpg", image_id):
            path = os.path.join(OUT_DIR, name)
            if os.path.isfile(path):
                with open(path, "rb") as fh:
                    return fh.read()
        return None

    def do_GET(self):
        path = self.path.split("?", 1)[0]
        if path == "/":
            return self._send_file(WEB_DIR, "index.html")
        if path == "/api/providers":
            return self._send_json(engine.provider_status())
        if path == "/api/gallery":
            query = parse_qs(self.path.partition("?")[2])

            def _qint(key, default, lo, hi):
                try:
                    return max(lo, min(hi, int(query.get(key, [default])[0])))
                except (TypeError, ValueError):
                    return default

            offset = _qint("offset", 0, 0, 10 ** 9)
            limit = _qint("limit", 60, 1, 200)
            images, total = engine.gallery(offset, limit)
            return self._send_json(
                {"images": images, "total": total, "offset": offset})
        if path == "/api/surprise":
            return self._send_json({"prompt": random.choice(SURPRISE_PROMPTS)})
        if path == "/api/x/status":
            return self._send_json(share_x.status())
        if path.startswith("/images/"):
            return self._send_file(OUT_DIR, path[len("/images/"):])
        return self._send_file(WEB_DIR, path.lstrip("/"))

    def do_POST(self):
        path = self.path.split("?", 1)[0]

        if path == "/api/x/connect":
            try:
                return self._send_json(share_x.begin_connect())
            except share_x.XError as exc:
                return self._send_json({"error": str(exc)}, 502)

        if path == "/api/x/connect/finish":
            req = self._read_json_body()
            if req is None:
                return
            pin = str(req.get("pin", "")).strip()
            if not pin:
                return self._send_json({"error": "pin is required"}, 400)
            try:
                return self._send_json(share_x.finish_connect(
                    pin, oauth_token=req.get("oauth_token")))
            except share_x.XError as exc:
                return self._send_json({"error": str(exc)}, 502)

        if path == "/api/x/disconnect":
            share_x.disconnect()
            return self._send_json(share_x.status())

        if path == "/api/x/share":
            req = self._read_json_body()
            if req is None:
                return
            image_id = str(req.get("id") or req.get("image_id") or "").strip()
            text = str(req.get("text", "")).strip()
            if not image_id:
                return self._send_json({"error": "image id is required"}, 400)
            if not text:
                return self._send_json({"error": "post text is required"}, 400)
            if len(text) > MAX_SHARE_TEXT:
                return self._send_json(
                    {"error": f"post text is over {MAX_SHARE_TEXT} characters"}, 400)
            data = self._image_bytes(image_id)
            if data is None:
                return self._send_json({"error": "image not found"}, 404)
            try:
                return self._send_json(share_x.share(data, text))
            except share_x.XError as exc:
                status = 401 if "connected" in str(exc).lower() else 502
                return self._send_json({"error": str(exc)}, status)

        if path == "/api/images/delete":
            req = self._read_json_body()
            if req is None:
                return
            image_id = str(req.get("id", "")).strip()
            if not image_id:
                return self._send_json({"error": "image id is required"}, 400)
            if not engine.delete(image_id):
                return self._send_json({"error": "image not found"}, 404)
            return self._send_json({"ok": True})

        if path != "/api/generate":
            return self._send_json({"error": "not found"}, 404)

        req = self._read_json_body()
        if req is None:
            return

        prompt = str(req.get("prompt", "")).strip()
        if not prompt:
            return self._send_json({"error": "prompt is required"}, 400)
        if len(prompt) > MAX_PROMPT_LENGTH:
            return self._send_json({"error": "prompt is too long"}, 400)

        try:
            n = max(1, min(MAX_IMAGES_PER_REQUEST, int(req.get("n", 1))))
        except (TypeError, ValueError):
            n = 1
        aspect = req.get("aspect") if req.get("aspect") in ASPECTS else "1:1"
        style = req.get("style") if req.get("style") in STYLES else "vivid"
        seed = req.get("seed")
        if seed is not None:
            try:
                seed = int(seed)
            except (TypeError, ValueError):
                seed = None
        provider = req.get("provider") or None

        image = req.get("image") or None
        if image is not None:
            if not isinstance(image, str) or not image.startswith("data:image/png;base64,"):
                return self._send_json(
                    {"error": "image must be a data:image/png;base64 URL"}, 400)
        try:
            strength = min(1.0, max(0.0, float(req.get("strength", 0.75))))
        except (TypeError, ValueError):
            strength = 0.75

        try:
            records = engine.generate(prompt, n=n, aspect=aspect, style=style,
                                      seed=seed, provider=provider,
                                      image=image, strength=strength)
        except ProviderError as exc:
            return self._send_json({"error": str(exc)}, 502)
        return self._send_json({"images": records})


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--host", default="127.0.0.1")
    parser.add_argument("--port", type=int, default=8000)
    args = parser.parse_args()

    server = ThreadingHTTPServer((args.host, args.port), Handler)
    status = engine.provider_status()
    x = share_x.status()
    print(f"Imagine Engine · http://{args.host}:{args.port}")
    print(f"  active provider: {status['active']}  (available: {', '.join(status['available'])})")
    if x.get("connected"):
        handle = f"@{x['handle']}" if x.get("handle") else "connected"
        auth = x.get("auth") or "user"
        print(f"  share to X: ready ({handle}, {auth})")
    elif x.get("configured"):
        print("  share to X: app keys set — connect account (PIN) or OAuth2 tokens")
    else:
        print("  share to X: set X credentials in .env")
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\nshutting down")


if __name__ == "__main__":
    main()
