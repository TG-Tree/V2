---
name: verify
description: Build/launch/drive recipe for verifying Imagine Engine changes end-to-end.
---

# Verifying Imagine Engine

Zero-dependency Python stdlib app. No build step, nothing to install.

## Test suite (run this first)

```bash
python3 -m unittest discover -s tests    # ~10s, includes freedom invariants,
                                         # mock-SD adapter, and live-API tests
```

## Launch

```bash
python3 server.py --port 8000   # from repo root; serves web UI + JSON API
```

Generated images + gallery index land in `generated/` (gitignored). Delete it
for a clean-slate run.

## Drive the API surface

```bash
curl -s http://127.0.0.1:8000/api/providers
curl -s -X POST http://127.0.0.1:8000/api/generate -H 'Content-Type: application/json' \
  -d '{"prompt":"sunset over mountains","n":2,"aspect":"16:9"}'
```

Dream renders take ~1s per image. Check PNG magic on `/images/<id>.png`.
Image-to-image: POST `"image": "data:image/png;base64,…"` + `"strength": 0.7`
— output must match input dimensions; the UI path to test without a file
dialog is lightbox → "Use as input".
Seed round-trip matters: re-POST with the returned `seed` and `cmp` the two
files — they must be byte-identical (seeds are 53-bit so they survive JS).

## Drive the UI surface

No playwright module; use the pre-installed Chromium directly:

- Static screenshot: `/opt/pw-browsers/chromium --headless=new --no-sandbox
  --window-size=1280,900 --virtual-time-budget=4000 --screenshot=ui.png
  http://127.0.0.1:8000/`
- Real clicks: launch with `--remote-debugging-port=9333`, then drive CDP over
  Node 22's built-in WebSocket (Runtime.evaluate to click #generate, poll
  `#generate.disabled`, Page.captureScreenshot). A working script pattern
  lives in session scratchpads as `cdp_drive.mjs`.

## Renderer-only checks

Visual inspection beats assertions: render prompts covering palettes
(sunset/neon/space/ice/forest) plus a no-keyword prompt (abstract mode), write
PNGs, and Read them as images. Watch for banding/striping in dark skies —
NoiseField interpolation artifacts show up there first.
