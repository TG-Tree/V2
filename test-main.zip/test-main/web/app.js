/* Imagine Engine front-end: no frameworks, just fetch + DOM. */

const $ = (id) => document.getElementById(id);

const state = {
  aspect: "1:1",
  aspects: ["1:1", "16:9", "9:16", "4:3", "3:4", "21:9"],
  provider: "dream",
  providers: ["dream"],
  providerInfo: {}, // name -> {label, local, img2img, seed, detail}
  generating: false,
  initImage: null, // data-URL PNG used for image-to-image
  history: { offset: 0, total: 0, pageSize: 60 },
  x: { configured: false, connected: false, handle: null },
  pendingOauthToken: null,
};

const ASPECT_CSS = {
  "1:1": "1 / 1", "16:9": "16 / 9", "9:16": "9 / 16",
  "4:3": "4 / 3", "3:4": "3 / 4", "21:9": "21 / 9",
};

/* ---- boot ---- */

async function boot() {
  try {
    const info = await fetch("/api/providers").then((r) => r.json());
    if (Array.isArray(info.aspects) && info.aspects.length) state.aspects = info.aspects;
    if (Array.isArray(info.available) && info.available.length) {
      state.providers = info.available;
    }
    if (Array.isArray(info.providers)) {
      for (const p of info.providers) state.providerInfo[p.name] = p;
    }
    // Default to server active, but always keep dream selectable (local freedom).
    state.provider = info.active || "dream";
    if (!state.providers.includes("dream")) state.providers = ["dream", ...state.providers];
    restoreSettings();
    renderProviderSelect();
    updateBadge();
  } catch {
    $("provider-badge").textContent = "engine: offline?";
    renderProviderSelect();
  }
  await refreshXStatus();
  renderAspectChips();
  await refreshHistory();
}

function updateBadge() {
  const inf = state.providerInfo[state.provider];
  const tag = inf ? (inf.local ? " · local" : " · cloud") : "";
  $("provider-badge").textContent = `engine: ${state.provider}${tag}`;
}

function renderProviderSelect() {
  const sel = $("provider");
  if (!sel) return;
  sel.innerHTML = "";
  for (const p of state.providers) {
    const opt = document.createElement("option");
    opt.value = p;
    const inf = state.providerInfo[p];
    opt.textContent = (inf && inf.label) || p;
    if (inf && inf.detail) opt.title = inf.detail;
    if (p === state.provider) opt.selected = true;
    sel.appendChild(opt);
  }
  sel.onchange = () => {
    setProvider(sel.value);
    saveSettings();
  };
}

/* ---- settings persistence (this browser only; nothing leaves the machine) */

const SETTINGS_KEY = "imagine-settings";

function saveSettings() {
  try {
    localStorage.setItem(SETTINGS_KEY, JSON.stringify({
      aspect: state.aspect,
      style: $("style").value,
      count: $("count").value,
      provider: state.provider,
    }));
  } catch { /* storage unavailable (private mode) — harmless */ }
}

function restoreSettings() {
  let saved;
  try { saved = JSON.parse(localStorage.getItem(SETTINGS_KEY)); } catch { return; }
  if (!saved) return;
  if (state.aspects.includes(saved.aspect)) state.aspect = saved.aspect;
  const styleSel = $("style");
  if ([...styleSel.options].some((o) => o.value === saved.style)) styleSel.value = saved.style;
  const countSel = $("count");
  if ([...countSel.options].some((o) => o.value === saved.count)) countSel.value = saved.count;
  if (state.providers.includes(saved.provider)) state.provider = saved.provider;
}

async function refreshXStatus() {
  try {
    state.x = await fetch("/api/x/status").then((r) => r.json());
  } catch {
    state.x = { configured: false, connected: false, handle: null };
  }
  const badge = $("x-badge");
  if (!state.x.configured) {
    badge.hidden = true;
    return;
  }
  badge.hidden = false;
  if (state.x.connected && state.x.handle) {
    badge.textContent = `@${state.x.handle}`;
    badge.classList.add("connected");
    badge.title = `Connected as @${state.x.handle} — click to disconnect`;
  } else {
    badge.textContent = "Connect X";
    badge.classList.remove("connected");
    badge.title = "Connect an X account to share images";
  }
}

function renderAspectChips() {
  const wrap = $("aspect-chips");
  wrap.innerHTML = "";
  for (const a of state.aspects) {
    const chip = document.createElement("button");
    chip.className = "chip" + (a === state.aspect ? " active" : "");
    chip.textContent = a;
    chip.onclick = () => {
      state.aspect = a;
      renderAspectChips();
      saveSettings();
    };
    wrap.appendChild(chip);
  }
}

/* ---- generation ---- */

async function generate() {
  if (state.generating) return;
  const prompt = $("prompt").value.trim();
  if (!prompt) {
    toast("Describe something first — or hit 🎲 Surprise me.");
    return;
  }
  const provider = $("provider")?.value || state.provider || "dream";
  const inf = state.providerInfo[provider];
  if (state.initImage && inf && inf.img2img === false) {
    toast(`${provider} can't edit images — use dream, sd, or replicate for image input.`, {
      label: "Switch to dream (local)",
      onClick: () => {
        setProvider("dream");
        generate();
      },
    });
    return;
  }
  const n = parseInt($("count").value, 10);
  const body = {
    prompt,
    n,
    aspect: state.aspect,
    style: $("style").value,
    provider,
  };
  const seedRaw = $("seed").value.trim();
  if (seedRaw) body.seed = seedRaw;
  if (state.initImage) {
    body.image = state.initImage;
    body.strength = parseInt($("strength").value, 10) / 100;
  }

  setGenerating(true);
  showPlaceholders(n);
  try {
    const resp = await fetch("/api/generate", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(body),
    });
    const data = await resp.json();
    if (!resp.ok) throw new Error(data.error || `HTTP ${resp.status}`);
    renderResults(data.images);
    await refreshHistory();
  } catch (err) {
    $("results-grid").innerHTML = "";
    $("results").hidden = true;
    if (body.provider !== "dream") {
      // Hosted provider failed — local generation always works.
      toast(err.message, {
        label: "Retry with dream (local)",
        onClick: () => {
          setProvider("dream");
          generate();
        },
      });
    } else {
      toast(err.message);
    }
  } finally {
    setGenerating(false);
  }
}

function setProvider(p) {
  state.provider = p;
  const sel = $("provider");
  if (sel && [...sel.options].some((o) => o.value === p)) sel.value = p;
  updateBadge();
}

function setGenerating(on) {
  state.generating = on;
  const btn = $("generate");
  btn.disabled = on;
  btn.textContent = on ? "Imagining…" : "Generate";
}

function showPlaceholders(n) {
  const grid = $("results-grid");
  grid.innerHTML = "";
  $("results").hidden = false;
  for (let i = 0; i < n; i++) {
    const ph = document.createElement("div");
    ph.className = "card placeholder";
    ph.style.setProperty("--ph-aspect", ASPECT_CSS[state.aspect] || "1 / 1");
    grid.appendChild(ph);
  }
  $("results").scrollIntoView({ behavior: "smooth", block: "nearest" });
}

function renderResults(images) {
  const grid = $("results-grid");
  grid.innerHTML = "";
  for (const img of images) grid.appendChild(card(img));
}

/* ---- cards + history ---- */

function card(rec) {
  const el = document.createElement("div");
  el.className = "card";
  el.dataset.id = rec.id;
  const img = document.createElement("img");
  img.src = rec.url;
  img.alt = rec.prompt;
  img.loading = "lazy";
  const cap = document.createElement("div");
  cap.className = "caption";
  cap.textContent = rec.prompt;
  el.append(img, cap);
  el.onclick = () => openLightbox(rec);
  return el;
}

async function fetchGallery(offset) {
  const resp = await fetch(`/api/gallery?offset=${offset}&limit=${state.history.pageSize}`);
  return resp.json();
}

async function refreshHistory() {
  try {
    const data = await fetchGallery(0);
    const grid = $("history-grid");
    grid.innerHTML = "";
    for (const rec of data.images) grid.appendChild(card(rec));
    state.history.offset = data.images.length;
    state.history.total = data.total ?? data.images.length;
    $("history-empty").hidden = data.images.length > 0;
    updateLoadMore();
  } catch {
    /* history is cosmetic; ignore fetch hiccups */
  }
}

async function loadMoreHistory() {
  try {
    const data = await fetchGallery(state.history.offset);
    const grid = $("history-grid");
    for (const rec of data.images) grid.appendChild(card(rec));
    state.history.offset += data.images.length;
    state.history.total = data.total ?? state.history.total;
    updateLoadMore();
  } catch {
    /* leave the button; the user can retry */
  }
}

function updateLoadMore() {
  $("history-more").hidden = state.history.offset >= state.history.total;
}

/* ---- lightbox ---- */

let lightboxRec = null;

function openLightbox(rec) {
  lightboxRec = rec;
  $("lightbox-img").src = rec.url;
  $("lb-prompt").textContent = rec.prompt;
  const bits = [rec.provider, rec.aspect, rec.style];
  if (rec.width && rec.height) bits.push(`${rec.width}×${rec.height}`);
  if (rec.seed != null) bits.push(`seed ${rec.seed}`);
  $("lb-meta").textContent = bits.filter(Boolean).join(" · ");
  const dl = $("lb-download");
  dl.href = rec.url;
  dl.download = `imagine-${rec.id}.${rec.url.split(".").pop()}`;
  $("lb-seed").hidden = rec.seed == null;
  $("lightbox").hidden = false;
}

function closeLightbox() {
  $("lightbox").hidden = true;
  lightboxRec = null;
}

function applyRecipe(rec, withSeed) {
  $("prompt").value = rec.prompt;
  // Without the seed the same recipe rolls a fresh variation; with it, an
  // exact reproduction (dream and sd honor seeds).
  $("seed").value = withSeed && rec.seed != null ? String(rec.seed) : "";
  if (state.aspects.includes(rec.aspect)) {
    state.aspect = rec.aspect;
    renderAspectChips();
  }
  const styleSel = $("style");
  if ([...styleSel.options].some((o) => o.value === rec.style)) {
    styleSel.value = rec.style;
  }
  if (state.providers.includes(rec.provider)) {
    setProvider(rec.provider);
  }
  closeLightbox();
  $("prompt").focus();
  window.scrollTo({ top: 0, behavior: "smooth" });
}

function remix() {
  if (lightboxRec) applyRecipe(lightboxRec, false);
}

function reuseSeed() {
  if (lightboxRec) applyRecipe(lightboxRec, true);
}

async function deleteImage() {
  if (!lightboxRec) return;
  if (!confirm("Delete this image? It will be removed from disk.")) return;
  const rec = lightboxRec;
  try {
    const resp = await fetch("/api/images/delete", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ id: rec.id }),
    });
    const data = await resp.json();
    if (!resp.ok) throw new Error(data.error || `HTTP ${resp.status}`);
    closeLightbox();
    for (const el of document.querySelectorAll(`.card[data-id="${rec.id}"]`)) el.remove();
    await refreshHistory();
    toast("Image deleted.");
  } catch (err) {
    toast(err.message);
  }
}

async function useAsInput() {
  if (!lightboxRec) return;
  const blob = await fetch(lightboxRec.url).then((r) => r.blob());
  await setInitImage(blob);
  closeLightbox();
  $("prompt").focus();
  window.scrollTo({ top: 0, behavior: "smooth" });
}

/* ---- share to X ---- */

function setShareError(msg) {
  const el = $("share-error");
  if (!msg) {
    el.hidden = true;
    el.textContent = "";
    return;
  }
  el.hidden = false;
  el.textContent = msg;
}

function showShareCompose() {
  $("share-compose").hidden = false;
  $("share-connect").hidden = true;
  $("share-title").textContent = "Share to X";
  $("share-sub").textContent = "Compose a post with this image.";
  $("share-account").textContent = state.x.handle ? `@${state.x.handle}` : "";
  const draft = (lightboxRec && lightboxRec.prompt) || "";
  $("share-text").value = draft.slice(0, 280);
  updateShareCount();
  setShareError(null);
}

function showShareConnect() {
  $("share-compose").hidden = true;
  $("share-connect").hidden = false;
  $("share-title").textContent = "Connect X";
  $("share-sub").textContent = "Authorize once — the token stays on this machine.";
  $("share-pin").value = "";
  setShareError(null);
}

function openShareModal() {
  if (!lightboxRec) return;
  if (!state.x.configured) {
    toast("Set X_CONSUMER_KEY / X_CONSUMER_SECRET in .env, then restart the server.");
    return;
  }
  $("share-modal").hidden = false;
  if (state.x.connected) showShareCompose();
  else showShareConnect();
}

function closeShareModal() {
  $("share-modal").hidden = true;
  state.pendingOauthToken = null;
  setShareError(null);
}

function updateShareCount() {
  const n = ($("share-text").value || "").length;
  $("share-count").textContent = `${n} / 280`;
}

async function beginXConnect() {
  setShareError(null);
  try {
    const resp = await fetch("/api/x/connect", { method: "POST" });
    const data = await resp.json();
    if (!resp.ok) throw new Error(data.error || `HTTP ${resp.status}`);
    state.pendingOauthToken = data.oauth_token;
    window.open(data.authorize_url, "_blank", "noopener,noreferrer");
  } catch (err) {
    setShareError(err.message);
  }
}

async function finishXConnect() {
  const pin = $("share-pin").value.trim();
  if (!pin) {
    setShareError("Enter the PIN from X.");
    return;
  }
  setShareError(null);
  $("share-connect-finish").disabled = true;
  try {
    const resp = await fetch("/api/x/connect/finish", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ pin, oauth_token: state.pendingOauthToken }),
    });
    const data = await resp.json();
    if (!resp.ok) throw new Error(data.error || `HTTP ${resp.status}`);
    await refreshXStatus();
    showShareCompose();
    toast(data.handle ? `Connected as @${data.handle}` : "X account connected");
  } catch (err) {
    setShareError(err.message);
  } finally {
    $("share-connect-finish").disabled = false;
  }
}

async function postToX() {
  if (!lightboxRec) return;
  const text = $("share-text").value.trim();
  if (!text) {
    setShareError("Write a caption first.");
    return;
  }
  setShareError(null);
  const btn = $("share-post");
  btn.disabled = true;
  btn.textContent = "Posting…";
  try {
    const resp = await fetch("/api/x/share", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ id: lightboxRec.id, text }),
    });
    const data = await resp.json();
    if (!resp.ok) throw new Error(data.error || `HTTP ${resp.status}`);
    closeShareModal();
    toast(data.url ? `Posted — ${data.url}` : "Posted to X");
    if (data.url) window.open(data.url, "_blank", "noopener,noreferrer");
  } catch (err) {
    setShareError(err.message);
  } finally {
    btn.disabled = false;
    btn.textContent = "Post";
  }
}

async function onXBadgeClick() {
  if (!state.x.configured) return;
  if (state.x.connected) {
    if (!confirm(state.x.handle
      ? `Disconnect @${state.x.handle}?`
      : "Disconnect X account?")) return;
    try {
      await fetch("/api/x/disconnect", { method: "POST" });
      await refreshXStatus();
      toast("Disconnected from X");
    } catch (err) {
      toast(err.message);
    }
    return;
  }
  // No image context — just run the connect flow.
  lightboxRec = lightboxRec || null;
  $("share-modal").hidden = false;
  showShareConnect();
}

/* ---- image input (upload / use-as-input) ---- */

const MAX_INPUT_DIM = 896; // keeps dream remixes fast and payloads small

async function setInitImage(blob) {
  try {
    const bitmap = await createImageBitmap(blob);
    const scale = Math.min(1, MAX_INPUT_DIM / Math.max(bitmap.width, bitmap.height));
    const w = Math.max(1, Math.round(bitmap.width * scale));
    const h = Math.max(1, Math.round(bitmap.height * scale));
    const canvas = document.createElement("canvas");
    canvas.width = w;
    canvas.height = h;
    canvas.getContext("2d").drawImage(bitmap, 0, 0, w, h);
    state.initImage = canvas.toDataURL("image/png"); // any input format -> PNG
    $("img-thumb").src = state.initImage;
    $("img-chip").hidden = false;
    $("strength-wrap").hidden = false;
  } catch {
    toast("Couldn't read that image — try a PNG or JPEG.");
  }
}

function clearInitImage() {
  state.initImage = null;
  $("img-chip").hidden = true;
  $("strength-wrap").hidden = true;
  $("file").value = "";
}

/* ---- misc ---- */

let toastTimer = null;
function toast(msg, action) {
  const el = $("toast");
  el.textContent = msg;
  if (action) {
    const btn = document.createElement("button");
    btn.className = "toast-action";
    btn.textContent = action.label;
    btn.onclick = () => {
      el.hidden = true;
      clearTimeout(toastTimer);
      action.onClick();
    };
    el.appendChild(btn);
  }
  el.hidden = false;
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => (el.hidden = true), action ? 12000 : 5000);
}

async function surprise() {
  try {
    const data = await fetch("/api/surprise").then((r) => r.json());
    $("prompt").value = data.prompt;
    $("prompt").focus();
  } catch {
    /* offline; leave the field as-is */
  }
}

$("generate").onclick = generate;
$("surprise").onclick = surprise;
$("lb-close").onclick = closeLightbox;
$("lb-share").onclick = openShareModal;
$("lb-remix").onclick = remix;
$("lb-use").onclick = useAsInput;
$("lb-seed").onclick = reuseSeed;
$("lb-delete").onclick = deleteImage;
$("history-more").onclick = loadMoreHistory;
$("style").onchange = saveSettings;
$("count").onchange = saveSettings;
$("upload").onclick = () => $("file").click();
$("file").onchange = () => { if ($("file").files[0]) setInitImage($("file").files[0]); };
$("img-clear").onclick = clearInitImage;
$("strength").oninput = () => {
  $("strength-val").textContent = (parseInt($("strength").value, 10) / 100).toFixed(2);
};
$("x-badge").onclick = onXBadgeClick;
$("share-cancel").onclick = closeShareModal;
$("share-connect-cancel").onclick = closeShareModal;
$("share-backdrop").onclick = closeShareModal;
$("share-text").oninput = updateShareCount;
$("share-open-auth").onclick = beginXConnect;
$("share-connect-finish").onclick = finishXConnect;
$("share-post").onclick = postToX;
document.querySelector(".lightbox-backdrop").onclick = closeLightbox;
document.addEventListener("keydown", (e) => {
  if (e.key === "Escape") {
    if (!$("share-modal").hidden) closeShareModal();
    else closeLightbox();
  }
  if ((e.metaKey || e.ctrlKey) && e.key === "Enter") generate();
});

boot();
