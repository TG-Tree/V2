# Imagine Engine — agent / contributor rules

## Non‑negotiable: creative freedom of the local setup

This product is a **self-hosted studio with a multi-provider router**. Improvements
must preserve creative freedom. Do **not** turn it into a single cloud-model
wrapper.

### Always keep

1. **`dream` stays available with zero config**  
   Pure stdlib procedural renderer. No API key, no network, no account.  
   Never remove, gate, or break the offline path.

2. **User can force local anytime**  
   - Env: `IMAGINE_PROVIDER=dream`  
   - Per request: `"provider": "dream"`  
   - UI must offer a way to pick `dream` when other providers exist.

3. **Hosted models are optional upgrades, not the only path**  
   Replicate / xAI / OpenAI (or future adapters) may be default *when keyed*,  
   but generation must still work with keys unset (falls back to `dream`).

4. **No app-level content censorship on the local path**  
   Do not add a global prompt blocklist, “safety rewrite,” or moderation layer  
   that runs on `dream` or on all providers by default.  
   Remote APIs may enforce their own policies; that stays *per provider*.  
   If a safety filter is added later, it must be **opt-in** and **provider-scoped**,  
   never forced on local `dream`.

5. **Download always works without X / social / accounts**  
   Share-to-X is optional. Images live under `generated/` and download from the UI.

6. **Secrets stay local**  
   `.env`, session files, tokens — gitignored. Never commit keys. Never require  
   secrets for basic generate + download.

7. **Stdlib-first**  
   Prefer Python stdlib + vanilla web. Do not force a heavy ML stack for the  
   default local experience.

### Creative freedom checklist (before merging)

- [ ] `python server.py` works with empty `.env` → `dream` generates  
- [ ] User can switch to `dream` even when Replicate/xAI is configured  
- [ ] No new mandatory cloud dependency for core generate/download  
- [ ] No global prompt filter that hits local generation  
- [ ] `.env` still gitignored; no secrets in repo  

### Preferred architecture

```
UI / API  →  ImagineEngine (router)  →  dream | replicate | xai | …
                                    ↘  always can choose dream
```

Add providers as **adapters** (`engine/providers.py` pattern). Do not hardcode  
a single remote model as the product.

### If improving quality toward “Imagine level”

- Prefer optional `xai` / Imagine API **alongside** local + Replicate  
- Keep Flux / other freer hosts as selectable alternatives  
- Never delete `dream` to “simplify”

### Out of scope for “freedom”

- Illegal content is still the user’s responsibility under the law  
- Remote providers (X, Replicate, xAI) keep their own ToS — we don’t bypass them  
- We also don’t *add* extra restrictions on the local stack without an explicit  
  product decision and an opt-out / local-only mode
