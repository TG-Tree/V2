# ✦ Imagine Engine

A self-hosted, Grok-Imagine-style text-to-image studio. Type a prompt, get
images — in a dark, minimal web UI with aspect ratios, styles, seeds, a
gallery, and remixing.

```
python3 server.py
# → http://localhost:8000
```

**Zero dependencies.** Python 3.8+ standard library only — no pip install, no
npm, no model downloads.

## Creative freedom (local setup)

This stays a **self-hosted multi-provider studio**, not a single cloud lock-in:

- **`dream` always works offline** — no keys, no network, no account.
- **Force local anytime:** `IMAGINE_PROVIDER=dream` or `"provider": "dream"` in the API.
- **Hosted models (Replicate, xAI, …) are optional** — quality upgrades, not requirements.
- **No app-wide prompt filter on the local path** — remote APIs may have their own rules; local generation does not add a second gate.
- **Download never requires X or social login.** Share-to-X is optional.

Agents and contributors: see **`AGENTS.md`** (and `CLAUDE.md` for Claude/Fable).

## How it works

The engine routes every request to a **provider**:

| Provider | What it is | Local | Image-to-image | Seeds | Enable with |
|----------|------------|-------|----------------|-------|-------------|
| `dream` (default) | Built-in procedural renderer. Parses your prompt for palettes and scene elements, then paints a deterministic, seeded artwork in pure Python. | ✅ | ✅ palette remix | ✅ | nothing — always available |
| `sd` | **Your own Stable Diffusion server** — any AUTOMATIC1111-compatible API (A1111, SD.Next, Forge). Real diffusion on your GPU, your models, your rules. | ✅ | ✅ diffusion | ✅ real seeds | `export SD_WEBUI_URL=http://127.0.0.1:7860` |
| `replicate` | Replicate-hosted diffusion — **FLUX.2 Max** by default, any model via env | — | ✅ diffusion | — | `export REPLICATE_API_TOKEN=…` |
| `xai` | xAI's Grok image API (`grok-2-image`) | — | — | — | `export XAI_API_KEY=…` |
| `openai` | OpenAI images (`gpt-image-1`) — or any OpenAI-compatible host (e.g. a self-hosted LocalAI) via `OPENAI_BASE_URL` | depends | — | — | `export OPENAI_API_KEY=…` |

When providers are configured the first available one becomes the default, in
**local-first order**: `sd` → `replicate` → `xai` → `openai`. Force a choice
with `export IMAGINE_PROVIDER=dream` (or pass `"provider"` per request).

Model/endpoint knobs: `XAI_IMAGE_MODEL`, `XAI_BASE_URL`, `OPENAI_IMAGE_MODEL`,
`OPENAI_BASE_URL`; on Replicate `REPLICATE_MODEL` (default
`black-forest-labs/flux-2-max`) and `REPLICATE_IMG2IMG_MODEL` (default
`black-forest-labs/flux-dev`), plus `REPLICATE_OUTPUT_QUALITY` (1–100,
default 100) and `REPLICATE_PROMPT_UPSAMPLING=true`.
Avoid `flux-schnell` for finals — it's the cheap draft model.
For local SD: `SD_WEBUI_STEPS` (default 28), `SD_WEBUI_SAMPLER`,
`SD_WEBUI_CFG`, `SD_WEBUI_NEGATIVE` (your negative prompt — the app never
adds one itself), `SD_WEBUI_TIMEOUT` (default 600s).
The adapter pattern (`engine/providers.py`) works for any HTTP endpoint —
each adapter is ~40 lines of stdlib urllib.

### The dream renderer

`dream` is an art engine, not a diffusion model. It reads the prompt for
keywords ("sunset", "cyberpunk", "nebula", "frozen ridge"…), picks a palette
and scene elements, derives a seed from the text, and composes the image in
layers: sky gradient → nebulae → stars → sun/moon → clouds → midpoint-
displacement mountain ridges → city skylines → water with ripple-displaced
reflections and specular light paths → film grain and vignette. Prompts with
no scenery cues get a domain-warped abstract flow-field instead.

Same prompt + same seed ⇒ pixel-identical image, so results are reproducible
and remixable. PNGs are encoded and decoded by hand (`engine/png.py`) —
that's how it stays dependency-free.

## Image-to-image

Upload any image (📎 in the UI — it's converted to PNG and downscaled
client-side) or click **Use as input** on any result, pick a strength, and
generate:

- **dream** restyles the input toward the prompt's palette (a seeded
  gradient remap + grain/vignette — think prompt-driven color grade, not
  semantic editing).
- **sd** runs true diffusion img2img on your own GPU, keeping the input's
  dimensions; strength maps to `denoising_strength`.
- **replicate** runs true diffusion img2img (`flux-dev` by default), where
  strength controls how far the model departs from your input.

Via the API, pass `"image": "data:image/png;base64,…"` and
`"strength": 0.0–1.0` to `/api/generate`.

## Web UI

- prompt bar with **Cmd/Ctrl+Enter** to generate, 🎲 surprise prompts
- aspect ratios (1:1, 16:9, 9:16, 4:3, 3:4, 21:9), styles (vivid, muted,
  mono, noir), 1–4 images per run, optional fixed seed
- results grid + persistent gallery of recent creations
- lightbox with download, **Share to X**, **remix** (reuse prompt, aspect,
  style, and provider — roll a new seed), **use seed** (exact reproduction,
  shown when the provider reports seeds), and **delete** (removes the image
  from disk and the gallery)
- if a hosted provider fails, the error toast offers one-click
  **Retry with dream (local)** — generation never depends on the cloud
- provider picker knows each engine's capabilities (local/cloud,
  image-to-image, seeds) and warns *before* sending an unsupported request
- gallery pages with **Load more** (index keeps up to 2000 creations);
  aspect/style/count/provider survive reloads via `localStorage`
- every saved PNG embeds its **recipe** (prompt, seed, provider, style,
  aspect) as standard iTXt metadata — downloaded files are self-documenting;
  read them back with `engine.png.read_metadata` or any EXIF tool

## Share to X

Post generated images to your X account from the lightbox. Credentials stay
local (`.env` and `.x_session.json` are gitignored).

1. Create an app in the [X developer portal](https://developer.x.com/) with
   **Read and Write** permissions and OAuth 1.0a **PIN** (out-of-band) enabled.
2. Put the consumer key pair in a `.env` at the repo root:

```
X_CONSUMER_KEY=…
X_CONSUMER_SECRET=…
# optional app-only bearer (read-only; not used for posting)
# X_BEARER_TOKEN=…
# optional: skip the UI PIN flow with a pre-issued user token pair
# X_ACCESS_TOKEN=…
# X_ACCESS_TOKEN_SECRET=…
```

3. Restart `server.py`. The header shows **Connect X** when keys are loaded.
4. Click **Connect X** (or **Share to X** on an image), authorize in the browser,
   paste the PIN — the access token is saved to `.x_session.json`.
5. Open any result → **Share to X** → caption → **Post**.

Posting needs user context (consumer key + access token). The app-only bearer
token cannot create posts.

## HTTP API

```bash
curl -X POST http://localhost:8000/api/generate \
  -H 'Content-Type: application/json' \
  -d '{"prompt": "neon skyline over a rainy bay", "n": 2, "aspect": "16:9", "style": "vivid"}'
```

| Endpoint | Method | Description |
|----------|--------|-------------|
| `/api/generate` | POST | `{prompt, n?, aspect?, style?, seed?, provider?, image?, strength?}` → `{images: [{id, url, seed, …}]}` |
| `/api/gallery` | GET | `?offset=&limit=` (default 60, max 200) → `{images, total, offset}`, newest first |
| `/api/images/delete` | POST | `{id}` → removes the image file and its gallery entry |
| `/api/providers` | GET | active/available providers with capability metadata, aspects, styles |
| `/api/surprise` | GET | a random prompt idea |
| `/api/x/status` | GET | `{configured, connected, handle}` for Share to X |
| `/api/x/connect` | POST | start PIN OAuth → `{authorize_url, oauth_token}` |
| `/api/x/connect/finish` | POST | `{pin, oauth_token?}` → `{handle}` |
| `/api/x/disconnect` | POST | drop the saved user session |
| `/api/x/share` | POST | `{id, text}` → `{id, url}` of the new post |
| `/images/<file>` | GET | the rendered images |

Errors come back as `{"error": "…"}` with a 4xx/5xx status.

## Layout

```
server.py            HTTP server + API (stdlib http.server)
engine/
  core.py            provider routing + gallery persistence
  dream.py           the procedural renderer
  prompt.py          prompt → palette/elements/seed
  noise.py           value noise, fBm, ridgelines
  png.py             minimal PNG encoder/decoder + recipe metadata (iTXt)
  providers.py       sd / replicate / xAI / OpenAI adapters (urllib)
  share_x.py         OAuth 1.0a + media upload for Share to X
web/                 the UI (vanilla HTML/CSS/JS)
tests/               stdlib unittest suite, incl. freedom-invariant tests
generated/           output images + gallery index (gitignored)
.env                 local secrets (gitignored)
.x_session.json      connected X user token (gitignored)
```

## Tests

```
python3 -m unittest discover -s tests
```

Zero test dependencies. `tests/test_freedom.py` encodes the AGENTS.md
creative-freedom checklist as regression tests: no keys → `dream` still
generates; `dream` stays selectable when hosted providers are keyed; prompts
pass through unfiltered; delete is traversal-guarded. `tests/test_sd_adapter.py`
exercises the local-SD path against a mock A1111 server, so it runs without
a GPU.

## Options

```
python3 server.py --host 0.0.0.0 --port 8000
```
