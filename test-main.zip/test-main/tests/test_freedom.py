"""The AGENTS.md creative-freedom checklist as executable regression tests.

These are the invariants the product must never lose:
- `dream` works with zero config (no keys, no network, no account)
- the user can force local generation even when hosted providers are keyed
- prompts are never filtered or rewritten on the local path
- images can always be deleted/downloaded locally, and delete is guarded
"""

import os
import tempfile
import unittest

from engine import png
from engine.core import ImagineEngine
from engine.providers import ProviderError

KEY_VARS = ("SD_WEBUI_URL", "REPLICATE_API_TOKEN", "XAI_API_KEY",
            "OPENAI_API_KEY", "IMAGINE_PROVIDER")


class FreedomTestCase(unittest.TestCase):
    """Isolates provider env vars and gives each test a fresh gallery dir."""

    def setUp(self):
        self._saved = {k: os.environ.pop(k, None) for k in KEY_VARS}
        self._tmp = tempfile.TemporaryDirectory()
        self.engine = ImagineEngine(self._tmp.name)

    def tearDown(self):
        for key, value in self._saved.items():
            if value is None:
                os.environ.pop(key, None)
            else:
                os.environ[key] = value
        self._tmp.cleanup()


class NoKeysStillWorks(FreedomTestCase):
    def test_default_provider_is_dream(self):
        self.assertEqual(self.engine.default_provider(), "dream")

    def test_dream_is_always_available(self):
        status = self.engine.provider_status()
        self.assertIn("dream", status["available"])
        dream_info = next(p for p in status["providers"] if p["name"] == "dream")
        self.assertTrue(dream_info["available"])
        self.assertTrue(dream_info["local"])

    def test_generate_works_offline(self):
        records = self.engine.generate("a quiet mountain lake at dusk")
        self.assertEqual(len(records), 1)
        path = os.path.join(self._tmp.name, f"{records[0]['id']}.png")
        self.assertTrue(os.path.isfile(path))


class LocalStaysSelectable(FreedomTestCase):
    def test_dream_selectable_when_remote_keyed(self):
        os.environ["REPLICATE_API_TOKEN"] = "fake-token-for-test"
        status = self.engine.provider_status()
        self.assertEqual(status["active"], "replicate")
        self.assertIn("dream", status["available"])
        records = self.engine.generate("forest river", provider="dream")
        self.assertEqual(records[0]["provider"], "dream")

    def test_env_can_force_local(self):
        os.environ["REPLICATE_API_TOKEN"] = "fake-token-for-test"
        os.environ["IMAGINE_PROVIDER"] = "dream"
        self.assertEqual(self.engine.default_provider(), "dream")

    def test_local_sd_outranks_hosted_defaults(self):
        os.environ["REPLICATE_API_TOKEN"] = "fake-token-for-test"
        os.environ["SD_WEBUI_URL"] = "http://127.0.0.1:7860"
        self.assertEqual(self.engine.default_provider(), "sd")
        sd_info = next(p for p in self.engine.provider_status()["providers"]
                       if p["name"] == "sd")
        self.assertTrue(sd_info["local"])
        self.assertTrue(sd_info["img2img"])


class PromptsAreNotFiltered(FreedomTestCase):
    def test_prompt_passes_through_verbatim(self):
        prompt = "an UNFILTERED prompt — köttbullar, 猫, «weird» punctuation!?"
        records = self.engine.generate(prompt)
        self.assertEqual(records[0]["prompt"], prompt)
        path = os.path.join(self._tmp.name, f"{records[0]['id']}.png")
        with open(path, "rb") as fh:
            meta = png.read_metadata(fh.read())
        self.assertEqual(meta["prompt"], prompt)
        self.assertEqual(meta["provider"], "dream")


class Determinism(FreedomTestCase):
    def test_seed_reproduces_exact_image(self):
        a = self.engine.generate("sunset over dunes", seed=1234)[0]
        b = self.engine.generate("sunset over dunes", seed=1234)[0]
        pa = os.path.join(self._tmp.name, f"{a['id']}.png")
        pb = os.path.join(self._tmp.name, f"{b['id']}.png")
        with open(pa, "rb") as fa, open(pb, "rb") as fb:
            da, db = fa.read(), fb.read()
        self.assertEqual(png.decode(da), png.decode(db))
        self.assertEqual(a["seed"], b["seed"])


class DeleteIsSafeAndLocal(FreedomTestCase):
    def test_delete_removes_file_and_record(self):
        rec = self.engine.generate("neon alley")[0]
        self.assertTrue(self.engine.delete(rec["id"]))
        images, total = self.engine.gallery()
        self.assertEqual(total, 0)
        self.assertFalse(
            os.path.isfile(os.path.join(self._tmp.name, f"{rec['id']}.png")))

    def test_delete_rejects_traversal_and_unknown(self):
        self.assertFalse(self.engine.delete("../server"))
        self.assertFalse(self.engine.delete(""))
        self.assertFalse(self.engine.delete("gallery"))
        self.assertFalse(self.engine.delete("no-such-id"))


class UnknownProvider(FreedomTestCase):
    def test_unknown_provider_raises(self):
        with self.assertRaises(ProviderError):
            self.engine.generate("anything", provider="not-a-provider")


if __name__ == "__main__":
    unittest.main()
