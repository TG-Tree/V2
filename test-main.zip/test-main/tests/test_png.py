"""PNG encoder/decoder and recipe-metadata round-trips."""

import unittest

from engine import png


def _checker(width, height):
    buf = bytearray(width * height * 3)
    for y in range(height):
        for x in range(width):
            i = (y * width + x) * 3
            v = 255 if (x + y) % 2 else 0
            buf[i] = v
            buf[i + 1] = 128
            buf[i + 2] = 255 - v
    return buf


class EncodeDecode(unittest.TestCase):
    def test_roundtrip(self):
        buf = _checker(12, 7)
        data = png.encode(12, 7, buf)
        w, h, out = png.decode(data)
        self.assertEqual((w, h), (12, 7))
        self.assertEqual(bytes(out), bytes(buf))

    def test_dimensions(self):
        data = png.encode(33, 21, bytearray(33 * 21 * 3))
        self.assertEqual(png.dimensions(data), (33, 21))
        self.assertIsNone(png.dimensions(b"\xff\xd8\xff not a png"))

    def test_buffer_size_check(self):
        with self.assertRaises(ValueError):
            png.encode(4, 4, bytearray(5))


class Metadata(unittest.TestCase):
    def test_metadata_roundtrip_including_unicode(self):
        data = png.encode(8, 8, _checker(8, 8))
        pairs = {
            "prompt": "café at midnight — 星空, quotes \"inside\"",
            "seed": 123456789,
            "provider": "dream",
            "skipped": None,  # None values are omitted
        }
        tagged = png.add_metadata(data, pairs)
        meta = png.read_metadata(tagged)
        self.assertEqual(meta["prompt"], pairs["prompt"])
        self.assertEqual(meta["seed"], "123456789")
        self.assertEqual(meta["provider"], "dream")
        self.assertNotIn("skipped", meta)

    def test_metadata_keeps_png_decodable(self):
        buf = _checker(10, 10)
        tagged = png.add_metadata(png.encode(10, 10, buf), {"prompt": "x"})
        self.assertEqual(png.dimensions(tagged), (10, 10))
        w, h, out = png.decode(tagged)
        self.assertEqual(bytes(out), bytes(buf))

    def test_non_png_is_returned_unchanged(self):
        blob = b"\xff\xd8\xff\xe0 fake jpeg bytes"
        self.assertEqual(png.add_metadata(blob, {"prompt": "x"}), blob)
        self.assertEqual(png.read_metadata(blob), {})


if __name__ == "__main__":
    unittest.main()
