"""HTTP API tests against a real server instance on an ephemeral port."""

import json
import os
import tempfile
import threading
import unittest
import urllib.error
import urllib.request
from http.server import ThreadingHTTPServer

import server
from engine.core import ImagineEngine


class ApiTest(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls._tmp = tempfile.TemporaryDirectory()
        cls._old_engine = server.engine
        cls._old_out = server.OUT_DIR
        server.engine = ImagineEngine(cls._tmp.name)
        server.OUT_DIR = cls._tmp.name
        cls.httpd = ThreadingHTTPServer(("127.0.0.1", 0), server.Handler)
        threading.Thread(target=cls.httpd.serve_forever, daemon=True).start()
        cls.base = f"http://127.0.0.1:{cls.httpd.server_address[1]}"

    @classmethod
    def tearDownClass(cls):
        cls.httpd.shutdown()
        cls.httpd.server_close()
        server.engine = cls._old_engine
        server.OUT_DIR = cls._old_out
        cls._tmp.cleanup()

    # -- helpers ---------------------------------------------------------------

    def _request(self, path, payload=None, raw=None):
        url = self.base + path
        if payload is not None or raw is not None:
            data = raw if raw is not None else json.dumps(payload).encode()
            req = urllib.request.Request(
                url, data=data, headers={"Content-Type": "application/json"})
        else:
            req = urllib.request.Request(url)
        try:
            with urllib.request.urlopen(req, timeout=60) as resp:
                return resp.status, resp.read()
        except urllib.error.HTTPError as exc:
            return exc.code, exc.read()

    def _json(self, path, payload=None, raw=None):
        status, body = self._request(path, payload, raw)
        return status, json.loads(body)

    def _generate(self, prompt, **kw):
        status, data = self._json(
            "/api/generate", {"prompt": prompt, "provider": "dream", **kw})
        self.assertEqual(status, 200, data)
        return data["images"]

    # -- tests -------------------------------------------------------------------

    def test_01_generate_and_fetch_image(self):
        images = self._generate("api smoke test", n=2, aspect="16:9")
        self.assertEqual(len(images), 2)
        for rec in images:
            self.assertEqual(rec["provider"], "dream")
            self.assertEqual(rec["aspect"], "16:9")
            status, body = self._request(rec["url"])
            self.assertEqual(status, 200)
            self.assertEqual(body[:8], b"\x89PNG\r\n\x1a\n")

    def test_02_gallery_pagination(self):
        self._generate("pagination fodder")
        status, data = self._json("/api/gallery?limit=2")
        self.assertEqual(status, 200)
        self.assertGreaterEqual(data["total"], 3)
        self.assertEqual(len(data["images"]), 2)
        status, page2 = self._json("/api/gallery?offset=2&limit=2")
        self.assertEqual(status, 200)
        ids1 = {r["id"] for r in data["images"]}
        ids2 = {r["id"] for r in page2["images"]}
        self.assertFalse(ids1 & ids2)

    def test_03_delete_flow(self):
        rec = self._generate("to be deleted")[0]
        status, data = self._json("/api/images/delete", {"id": rec["id"]})
        self.assertEqual(status, 200)
        self.assertTrue(data.get("ok"))
        status, _ = self._json("/api/images/delete", {"id": rec["id"]})
        self.assertEqual(status, 404)
        status, _ = self._json("/api/images/delete", {"id": "../../etc/passwd"})
        self.assertEqual(status, 404)

    def test_bad_requests(self):
        status, data = self._json("/api/generate", {"prompt": ""})
        self.assertEqual(status, 400)
        status, data = self._json("/api/generate", {"prompt": "x" * 3000})
        self.assertEqual(status, 400)
        status, data = self._json("/api/generate", raw=b"{not json")
        self.assertEqual(status, 400)
        status, data = self._json(
            "/api/generate", {"prompt": "x", "image": "http://evil"})
        self.assertEqual(status, 400)
        status, data = self._json(
            "/api/generate", {"prompt": "x", "provider": "bogus"})
        self.assertEqual(status, 502)

    def test_providers_endpoint(self):
        status, data = self._json("/api/providers")
        self.assertEqual(status, 200)
        self.assertIn("dream", data["available"])
        names = [p["name"] for p in data["providers"]]
        self.assertEqual(names[0], "dream")
        self.assertIn("sd", names)

    def test_image_route_traversal_guard(self):
        status, _ = self._request("/images/../server.py")
        self.assertEqual(status, 404)
        status, _ = self._request("/images/.hidden")
        self.assertEqual(status, 404)

    def test_unknown_route(self):
        status, _ = self._request("/api/nope", payload={})
        self.assertEqual(status, 404)


if __name__ == "__main__":
    unittest.main()
