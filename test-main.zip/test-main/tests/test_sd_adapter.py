"""sd adapter against a mock AUTOMATIC1111-compatible server.

Verifies the full local-diffusion path without needing a GPU: request shape
(endpoint, dimensions, batch size, strength), grid trimming, and real-seed
passthrough from the response `info`.
"""

import base64
import json
import os
import threading
import unittest
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

from engine import png
from engine.providers import ProviderError, sd_generate

_TINY_PNG = png.encode(8, 8, bytearray(8 * 8 * 3))
_TINY_B64 = base64.b64encode(_TINY_PNG).decode("ascii")


class _MockSD(BaseHTTPRequestHandler):
    calls = []

    def do_POST(self):
        length = int(self.headers.get("Content-Length", 0))
        body = json.loads(self.rfile.read(length))
        _MockSD.calls.append((self.path, body))
        n = int(body.get("batch_size", 1))
        images = [_TINY_B64] * n
        if n > 1:
            images = [_TINY_B64] + images  # webui may prepend a grid image
        payload = json.dumps({
            "images": images,
            "info": json.dumps({"all_seeds": [100 + i for i in range(n)]}),
        }).encode("utf-8")
        self.send_response(200)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(payload)))
        self.end_headers()
        self.wfile.write(payload)

    def log_message(self, fmt, *args):
        pass


class SdAdapterTest(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.httpd = ThreadingHTTPServer(("127.0.0.1", 0), _MockSD)
        threading.Thread(target=cls.httpd.serve_forever, daemon=True).start()
        cls.url = f"http://127.0.0.1:{cls.httpd.server_address[1]}"

    @classmethod
    def tearDownClass(cls):
        cls.httpd.shutdown()
        cls.httpd.server_close()

    def setUp(self):
        _MockSD.calls.clear()
        os.environ["SD_WEBUI_URL"] = self.url

    def tearDown(self):
        os.environ.pop("SD_WEBUI_URL", None)

    def test_txt2img_batch_with_grid_trim_and_seeds(self):
        out = sd_generate("a red fox", 2, "16:9", style="vivid")
        self.assertEqual(len(out), 2)
        for data, seed in out:
            self.assertEqual(data[:8], b"\x89PNG\r\n\x1a\n")
        self.assertEqual([seed for _, seed in out], [100, 101])

        path, body = _MockSD.calls[0]
        self.assertEqual(path, "/sdapi/v1/txt2img")
        self.assertEqual((body["width"], body["height"]), (1024, 576))
        self.assertEqual(body["batch_size"], 2)
        self.assertEqual(body["seed"], -1)
        self.assertIn("a red fox", body["prompt"])

    def test_seed_is_forwarded(self):
        sd_generate("still life", 1, "1:1", seed=777)
        _, body = _MockSD.calls[0]
        self.assertEqual(body["seed"], 777)

    def test_img2img_keeps_input_dimensions(self):
        src = png.encode(100, 72, bytearray(100 * 72 * 3))
        data_url = "data:image/png;base64," + base64.b64encode(src).decode("ascii")
        out = sd_generate("repaint it", 1, "1:1", image=data_url, strength=0.4)
        self.assertEqual(len(out), 1)

        path, body = _MockSD.calls[0]
        self.assertEqual(path, "/sdapi/v1/img2img")
        self.assertEqual(body["denoising_strength"], 0.4)
        # input dims rounded down to a multiple of 8 (with a 64px floor)
        self.assertEqual((body["width"], body["height"]), (96, 72))
        self.assertEqual(len(body["init_images"]), 1)

    def test_missing_env_raises(self):
        os.environ.pop("SD_WEBUI_URL", None)
        with self.assertRaises(ProviderError):
            sd_generate("x", 1, "1:1")


if __name__ == "__main__":
    unittest.main()
